import React, { useState, useMemo } from 'react';
import {
  CIRCUIT_PRESETS,
  CircuitGate,
  CircuitPreset,
  CloudJobRecord,
  DomainCategory,
  HybridWorkflowPreset,
  INITIAL_CLOUD_JOBS,
  QUANTUM_BACKENDS,
  QuantumBackend,
  simulateQuantumCircuit,
} from './lib/quantumEngine';
import { CircuitStudioView } from './components/CircuitStudioView';
import { QuantumBackendsView } from './components/QuantumBackendsView';
import { HybridWorkflowsView } from './components/HybridWorkflowsView';
import { SdkTranspilerView } from './components/SdkTranspilerView';
import { JobQueueView } from './components/JobQueueView';

type ActiveSection =
  | 'studio'
  | 'backends'
  | 'workflows'
  | 'sdk'
  | 'queue';

export default function App() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('studio');
  const [activePreset, setActivePreset] = useState<CircuitPreset>(
    CIRCUIT_PRESETS[0]
  );
  const [numQubits, setNumQubits] = useState<number>(
    CIRCUIT_PRESETS[0].numQubits
  );
  const [gates, setGates] = useState<CircuitGate[]>(CIRCUIT_PRESETS[0].gates);
  const [shots, setShots] = useState<number>(4096);
  const [useNoiseModel, setUseNoiseModel] = useState<boolean>(true);
  const [activeBackend, setActiveBackend] = useState<QuantumBackend>(
    QUANTUM_BACKENDS[0]
  );
  const [domainFilter, setDomainFilter] = useState<DomainCategory | 'all'>(
    'all'
  );
  const [jobs, setJobs] = useState<CloudJobRecord[]>(INITIAL_CLOUD_JOBS);
  const [lastDispatchedNotice, setLastDispatchedNotice] = useState<string | null>(
    null
  );

  // Real-time quantum statevector + hardware noise simulation
  const simulation = useMemo(() => {
    return simulateQuantumCircuit(
      numQubits,
      gates,
      shots,
      activeBackend,
      useNoiseModel
    );
  }, [numQubits, gates, shots, activeBackend, useNoiseModel]);

  const handleSelectPreset = (preset: CircuitPreset) => {
    setActivePreset(preset);
    setNumQubits(preset.numQubits);
    setGates(preset.gates.map((g) => ({ ...g })));
  };

  const handleSubmitCloudJob = () => {
    const newJobId = `job-${Math.floor(9483 + Math.random() * 900)}-${activePreset.domain.slice(
      0,
      3
    )}`;
    const topBasis = [...simulation.basisStates].sort(
      (a, b) => b.probability - a.probability
    )[0];

    const newJob: CloudJobRecord = {
      id: newJobId,
      name: `${activePreset.name.replace(/\s+/g, '-')}-Run`,
      domain: activePreset.domain,
      backendId: activeBackend.id,
      backendName: activeBackend.name,
      algorithm:
        activePreset.domain === 'pharma'
          ? 'UCCSD VQE'
          : activePreset.domain === 'finance'
          ? 'Iterative QAE'
          : 'State Tomography',
      qubits: numQubits,
      depth: simulation.circuitDepth,
      shots,
      status: 'COMPLETED',
      submittedAt: 'Just now',
      qpuRuntimeMs: Math.max(
        35,
        Math.round((simulation.estimatedDurationNs * shots) / 950)
      ),
      fidelity: simulation.estimatedFidelity,
      keyResult: `Peak |${topBasis?.bitstring ?? '0000'}⟩ (${(
        (topBasis?.probability ?? 1) * 100
      ).toFixed(1)}%)`,
      presetId: activePreset.id,
    };

    setJobs((prev) => [newJob, ...prev]);
    setLastDispatchedNotice(
      `Dispatched ${newJob.id} to ${activeBackend.name} (${shots.toLocaleString()} shots · Fidelity ${(
        simulation.estimatedFidelity * 100
      ).toFixed(2)}%)`
    );
  };

  const handleLogWorkflowJob = (
    workflow: HybridWorkflowPreset,
    finalVal: number
  ) => {
    const newJobId = `job-${Math.floor(9550 + Math.random() * 400)}-hyb`;
    const newJob: CloudJobRecord = {
      id: newJobId,
      name: workflow.name.replace(/\s+/g, '-'),
      domain: workflow.domain,
      backendId: activeBackend.id,
      backendName: activeBackend.name,
      algorithm: `${workflow.algorithm} Hybrid Loop`,
      qubits: 5,
      depth: 24,
      shots: 8192,
      status: 'COMPLETED',
      submittedAt: 'Just now',
      qpuRuntimeMs: 1420,
      fidelity: 0.984,
      keyResult: `${finalVal.toFixed(4)} ${workflow.unit}`,
      presetId:
        workflow.domain === 'pharma'
          ? 'pharma-kras-pocket'
          : workflow.domain === 'finance'
          ? 'finance-cvar-qae'
          : 'research-ising-trotter',
    };
    setJobs((prev) => [newJob, ...prev]);
    setLastDispatchedNotice(
      `Completed Hybrid ${workflow.algorithm} Job ${newJobId} on ${activeBackend.name}: ${finalVal.toFixed(
        4
      )} ${workflow.unit}`
    );
  };

  const navItems: { id: ActiveSection; label: string }[] = [
    { id: 'studio', label: 'Circuit Studio' },
    { id: 'backends', label: 'Quantum Backends' },
    { id: 'workflows', label: 'Hybrid Workflows' },
    { id: 'sdk', label: 'SDK & OpenQASM' },
    { id: 'queue', label: 'Job Queue' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#07090E] text-slate-100">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800 bg-[#0B0E17] sticky top-0 z-30">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#studio"
          onClick={(e) => {
            e.preventDefault();
            setActiveSection('studio');
          }}
          className="font-display text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
        >
          Veritas Quantum
        </a>

        {/* Zone 2: 5 clean text navigation links with subtle hover/active underlines */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveSection(item.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 cursor-pointer ${
                  isActive
                    ? 'text-cyan-400 border-cyan-400'
                    : 'text-slate-400 border-transparent hover:text-slate-100 hover:border-slate-700'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 2 primary actions */}
        <div className="flex items-center gap-3 shrink-0">
          <select
            aria-label="Target Quantum Processor"
            value={activeBackend.id}
            onChange={(e) => {
              const found = QUANTUM_BACKENDS.find(
                (b) => b.id === e.target.value
              );
              if (found) setActiveBackend(found);
            }}
            className="bg-[#111827] border border-slate-700 text-xs font-mono text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 whitespace-nowrap cursor-pointer"
          >
            {QUANTUM_BACKENDS.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.qubits}Q)
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={handleSubmitCloudJob}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-500 hover:bg-cyan-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Execute Circuit
          </button>
        </div>
      </header>

      {/* Mobile Navigation Sub-Bar (visible only below md) */}
      <div className="flex md:hidden items-center gap-4 overflow-x-auto px-6 py-2.5 bg-[#0B0E17] border-b border-slate-800 text-xs font-medium">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveSection(item.id)}
            className={`whitespace-nowrap shrink-0 pb-1 border-b-2 ${
              activeSection === item.id
                ? 'text-cyan-400 border-cyan-400 font-semibold'
                : 'text-slate-400 border-transparent'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Dispatched Job Confirmation Ribbon */}
      {lastDispatchedNotice && (
        <div className="bg-cyan-950/60 border-b border-cyan-500/40 px-6 py-2 flex items-center justify-between text-xs font-mono">
          <span className="text-cyan-200 truncate">{lastDispatchedNotice}</span>
          <div className="flex items-center gap-4 shrink-0 ml-4">
            <button
              type="button"
              onClick={() => {
                setActiveSection('queue');
                setLastDispatchedNotice(null);
              }}
              className="text-cyan-300 underline hover:text-white whitespace-nowrap cursor-pointer"
            >
              Inspect in Job Queue
            </button>
            <button
              type="button"
              onClick={() => setLastDispatchedNotice(null)}
              className="text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Content Container (1440px desktop presence) */}
      <main className="flex-1 w-full max-w-[1440px] mx-auto px-6 py-6">
        {activeSection === 'studio' && (
          <CircuitStudioView
            numQubits={numQubits}
            setNumQubits={setNumQubits}
            gates={gates}
            setGates={setGates}
            shots={shots}
            setShots={setShots}
            useNoiseModel={useNoiseModel}
            setUseNoiseModel={setUseNoiseModel}
            activeBackend={activeBackend}
            simulation={simulation}
            activePreset={activePreset}
            onSelectPreset={handleSelectPreset}
            onSubmitCloudJob={handleSubmitCloudJob}
            domainFilter={domainFilter}
            setDomainFilter={setDomainFilter}
          />
        )}

        {activeSection === 'backends' && (
          <QuantumBackendsView
            activeBackend={activeBackend}
            onSelectBackend={(b) => setActiveBackend(b)}
            onNavigateToStudio={() => setActiveSection('studio')}
          />
        )}

        {activeSection === 'workflows' && (
          <HybridWorkflowsView
            activeBackend={activeBackend}
            onLogWorkflowJob={handleLogWorkflowJob}
          />
        )}

        {activeSection === 'sdk' && (
          <SdkTranspilerView
            numQubits={numQubits}
            gates={gates}
            shots={shots}
            activeBackend={activeBackend}
            activePreset={activePreset}
            simulation={simulation}
          />
        )}

        {activeSection === 'queue' && (
          <JobQueueView
            jobs={jobs}
            onLoadPresetFromJob={(preset) => {
              handleSelectPreset(preset);
              setActiveSection('studio');
            }}
            onDispatchNewJob={() => {
              handleSubmitCloudJob();
            }}
          />
        )}
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-slate-800/80 bg-[#0B0E17] px-6 py-4 mt-12">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            Veritas Quantum Cloud · Cryogenic Superconducting, Trapped-Ion & Neutral-Atom Compute Fabric
          </div>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => {
                setDomainFilter('pharma');
                setActiveSection('studio');
              }}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Pharmaceutical VQE
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => {
                setDomainFilter('finance');
                setActiveSection('studio');
              }}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Quantitative Finance QAE
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => {
                setDomainFilter('research');
                setActiveSection('studio');
              }}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Many-Body Physics Research
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
