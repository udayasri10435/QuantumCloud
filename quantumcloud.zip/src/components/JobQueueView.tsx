import React, { useState } from 'react';
import {
  CIRCUIT_PRESETS,
  CircuitPreset,
  CloudJobRecord,
  DomainCategory,
} from '../lib/quantumEngine';
import { Search, ArrowUpRight, Plus } from 'lucide-react';

interface JobQueueViewProps {
  jobs: CloudJobRecord[];
  onLoadPresetFromJob: (preset: CircuitPreset) => void;
  onDispatchNewJob: () => void;
}

export const JobQueueView: React.FC<JobQueueViewProps> = ({
  jobs,
  onLoadPresetFromJob,
  onDispatchNewJob,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [domainFilter, setDomainFilter] = useState<DomainCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<
    'ALL' | 'COMPLETED' | 'RUNNING' | 'QUEUED'
  >('ALL');

  const filteredJobs = jobs.filter((job) => {
    const matchesDomain =
      domainFilter === 'all' || job.domain === domainFilter;
    const matchesStatus =
      statusFilter === 'ALL' || job.status === statusFilter;
    const q = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !q ||
      job.name.toLowerCase().includes(q) ||
      job.id.toLowerCase().includes(q) ||
      job.backendName.toLowerCase().includes(q) ||
      job.algorithm.toLowerCase().includes(q);
    return matchesDomain && matchesStatus && matchesQuery;
  });

  const totalQpuRuntimeSec = (
    jobs.reduce((acc, j) => acc + j.qpuRuntimeMs, 0) / 1000
  ).toFixed(2);
  const totalShotsExecuted = jobs.reduce((acc, j) => acc + j.shots, 0);
  const meanFidelity =
    jobs.length > 0
      ? (
          (jobs.reduce((acc, j) => acc + j.fidelity, 0) / jobs.length) *
          100
        ).toFixed(2)
      : '0.00';

  return (
    <div className="space-y-6">
      {/* Top Summary Metrics Bar */}
      <div className="bg-[#111827] border border-slate-800 p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div>
          <div className="text-xs text-slate-400">Total Dispatched Jobs</div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold text-slate-100 tabular-nums">
              {jobs.length}
            </span>
            <span className="text-xs font-mono text-emerald-400 ml-2">
              ● {jobs.filter((j) => j.status === 'COMPLETED').length} COMPLETED
            </span>
          </div>
        </div>

        <div>
          <div className="text-xs text-slate-400">Cumulative QPU Runtime</div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold text-cyan-400 tabular-nums">
              {totalQpuRuntimeSec}
            </span>
            <span className="text-xs font-mono text-slate-400 ml-1.5">
              sec coherent execution
            </span>
          </div>
        </div>

        <div>
          <div className="text-xs text-slate-400">Total Measurement Shots</div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold text-slate-100 tabular-nums">
              {totalShotsExecuted.toLocaleString()}
            </span>
            <span className="text-xs font-mono text-slate-400 ml-1.5">
              readout triggers
            </span>
          </div>
        </div>

        <div>
          <div className="text-xs text-slate-400">Fleet Mean Circuit Fidelity</div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold text-emerald-400 tabular-nums">
              {meanFidelity}
            </span>
            <span className="text-xs font-mono text-slate-400 ml-1.5">
              % post-mitigation
            </span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar + High-Density Execution Ledger */}
      <div className="bg-[#111827] border border-slate-800">
        <div className="p-5 border-b border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search job ID, molecule, QPU..."
                className="bg-[#07090E] border border-slate-800 focus:border-cyan-500 outline-none pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 w-64 font-mono"
              />
            </div>

            {/* Domain Filter */}
            <div className="flex items-center gap-1 p-1 bg-[#07090E] border border-slate-800">
              {(['all', 'pharma', 'finance', 'research'] as const).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDomainFilter(d)}
                  className={`px-2.5 py-1 text-xs font-medium capitalize transition-colors whitespace-nowrap cursor-pointer ${
                    domainFilter === d
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 p-1 bg-[#07090E] border border-slate-800">
              {(['ALL', 'COMPLETED', 'RUNNING', 'QUEUED'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 text-xs font-mono transition-colors whitespace-nowrap cursor-pointer ${
                    statusFilter === st
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={onDispatchNewJob}
            className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer self-start lg:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            Dispatch Studio Circuit
          </button>
        </div>

        {/* Table or Empty State */}
        {filteredJobs.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-[#0B0E17] text-[11px] font-mono text-slate-400">
                  <th className="py-2.5 px-4">JOB ID & WORKLOAD</th>
                  <th className="py-2.5 px-3">DOMAIN · ALGORITHM</th>
                  <th className="py-2.5 px-3">TARGET BACKEND</th>
                  <th className="py-2.5 px-3 text-right">REGISTER · DEPTH</th>
                  <th className="py-2.5 px-3 text-right">SHOTS · TIME</th>
                  <th className="py-2.5 px-3 text-right">OBSERVABLE RESULT</th>
                  <th className="py-2.5 px-3 text-right">STATUS</th>
                  <th className="py-2.5 px-4 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-xs">
                {filteredJobs.map((job) => {
                  const matchedPreset =
                    CIRCUIT_PRESETS.find((p) => p.id === job.presetId) ||
                    CIRCUIT_PRESETS[0];
                  return (
                    <tr
                      key={job.id}
                      className="hover:bg-slate-800/35 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100">
                          {job.name}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 mt-0.5 tabular-nums">
                          {job.id} · {job.submittedAt}
                        </div>
                      </td>

                      <td className="py-3 px-3 text-slate-300">
                        <span className="capitalize text-cyan-300">
                          {job.domain}
                        </span>
                        <span aria-hidden="true" className="mx-1.5 text-slate-600">
                          ·
                        </span>
                        <span className="font-mono">{job.algorithm}</span>
                      </td>

                      <td className="py-3 px-3 font-mono text-slate-200">
                        {job.backendName}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                        {job.qubits}Q · d={job.depth}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                        {job.shots.toLocaleString()} · {job.qpuRuntimeMs} ms
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-cyan-300 font-semibold">
                        {job.keyResult}
                      </td>

                      <td className="py-3 px-3 text-right font-mono whitespace-nowrap">
                        {job.status === 'COMPLETED' ? (
                          <span className="text-emerald-400">● COMPLETED</span>
                        ) : job.status === 'RUNNING' ? (
                          <span className="text-cyan-400">● RUNNING</span>
                        ) : (
                          <span className="text-amber-400">▲ QUEUED</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => onLoadPresetFromJob(matchedPreset)}
                          className="inline-flex items-center gap-1 text-xs font-mono text-slate-300 hover:text-cyan-300 transition-colors whitespace-nowrap cursor-pointer"
                        >
                          <span>Inspect</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center space-y-3">
            <div className="text-sm font-semibold text-slate-200">
              No Quantum Execution Jobs Match Current Filter
            </div>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Clear your search filter criteria or dispatch a new quantum statevector / QPU hardware execution from the Circuit Studio.
            </p>
            <div className="pt-2 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setDomainFilter('all');
                  setStatusFilter('ALL');
                }}
                className="px-4 py-2 bg-[#0B0E17] border border-slate-800 text-xs font-medium text-slate-200 hover:border-slate-600 cursor-pointer"
              >
                Reset Filter Criteria
              </button>
              <button
                type="button"
                onClick={onDispatchNewJob}
                className="px-4 py-2 bg-cyan-500 text-slate-950 font-semibold text-xs hover:bg-cyan-400 cursor-pointer"
              >
                Dispatch First Job
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
