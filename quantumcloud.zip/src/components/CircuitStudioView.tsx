import React, { useState } from 'react';
import {
  CIRCUIT_PRESETS,
  CircuitGate,
  CircuitPreset,
  DomainCategory,
  GateType,
  QuantumBackend,
  SimulationResult,
} from '../lib/quantumEngine';
import { Play, RotateCcw, Trash2, Plus, Sliders } from 'lucide-react';

interface CircuitStudioViewProps {
  numQubits: number;
  setNumQubits: (n: number) => void;
  gates: CircuitGate[];
  setGates: React.Dispatch<React.SetStateAction<CircuitGate[]>>;
  shots: number;
  setShots: (s: number) => void;
  useNoiseModel: boolean;
  setUseNoiseModel: (b: boolean) => void;
  activeBackend: QuantumBackend;
  simulation: SimulationResult;
  activePreset: CircuitPreset;
  onSelectPreset: (preset: CircuitPreset) => void;
  onSubmitCloudJob: () => void;
  domainFilter: DomainCategory | 'all';
  setDomainFilter: (d: DomainCategory | 'all') => void;
}

const GATE_PALETTE: {
  type: GateType;
  label: string;
  category: 'Clifford' | 'Rotation' | 'Entangling';
  desc: string;
}[] = [
  { type: 'H', label: 'H', category: 'Clifford', desc: 'Hadamard superposition' },
  { type: 'X', label: 'X', category: 'Clifford', desc: 'Pauli-X bit flip' },
  { type: 'Y', label: 'Y', category: 'Clifford', desc: 'Pauli-Y bit & phase flip' },
  { type: 'Z', label: 'Z', category: 'Clifford', desc: 'Pauli-Z phase flip' },
  { type: 'S', label: 'S', category: 'Clifford', desc: 'π/2 Z-phase gate' },
  { type: 'T', label: 'T', category: 'Clifford', desc: 'π/4 non-Clifford gate' },
  { type: 'RX', label: 'RX(θ)', category: 'Rotation', desc: 'X-axis rotation by θ' },
  { type: 'RY', label: 'RY(θ)', category: 'Rotation', desc: 'Y-axis rotation by θ' },
  { type: 'RZ', label: 'RZ(θ)', category: 'Rotation', desc: 'Z-axis phase rotation by θ' },
  { type: 'CNOT', label: 'CX', category: 'Entangling', desc: 'Controlled-NOT entangler' },
  { type: 'CZ', label: 'CZ', category: 'Entangling', desc: 'Controlled-Z phase entangler' },
  { type: 'SWAP', label: 'SWAP', category: 'Entangling', desc: 'Two-qubit state exchange' },
];

const TOTAL_STEPS = 11;

export const CircuitStudioView: React.FC<CircuitStudioViewProps> = ({
  numQubits,
  setNumQubits,
  gates,
  setGates,
  shots,
  setShots,
  useNoiseModel,
  setUseNoiseModel,
  activeBackend,
  simulation,
  activePreset,
  onSelectPreset,
  onSubmitCloudJob,
  domainFilter,
  setDomainFilter,
}) => {
  const [selectedToolGate, setSelectedToolGate] = useState<GateType>('RY');
  const [defaultAngle, setDefaultAngle] = useState<number>(0.7854); // pi/4
  const [targetOffset, setTargetOffset] = useState<number>(1);
  const [selectedGateId, setSelectedGateId] = useState<string | null>(null);
  const [hoveredBitstring, setHoveredBitstring] = useState<string | null>(null);

  const selectedGateObj = gates.find((g) => g.id === selectedGateId) || null;

  const filteredPresets =
    domainFilter === 'all'
      ? CIRCUIT_PRESETS
      : CIRCUIT_PRESETS.filter((p) => p.domain === domainFilter);

  const handleCellClick = (qubit: number, step: number) => {
    // Check if there is already a gate at this qubit & step
    const existing = gates.find((g) => g.qubit === qubit && g.step === step);
    if (existing) {
      if (selectedGateId === existing.id) {
        // Clicking again removes the gate
        setGates((prev) => prev.filter((g) => g.id !== existing.id));
        setSelectedGateId(null);
      } else {
        setSelectedGateId(existing.id);
      }
      return;
    }

    // Check if this cell is currently a target of a 2-qubit gate at the same step
    const existingTarget = gates.find(
      (g) => g.step === step && g.targetQubit === qubit
    );
    if (existingTarget) {
      setSelectedGateId(existingTarget.id);
      return;
    }

    // Place a new gate
    const isTwoQubit =
      selectedToolGate === 'CNOT' ||
      selectedToolGate === 'CZ' ||
      selectedToolGate === 'SWAP';
    const isRotation =
      selectedToolGate === 'RX' ||
      selectedToolGate === 'RY' ||
      selectedToolGate === 'RZ';

    const computedTarget = isTwoQubit
      ? (qubit + targetOffset) % numQubits
      : undefined;

    // Remove any conflicting gate on target qubit at same step
    const newId = `g-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newGate: CircuitGate = {
      id: newId,
      type: selectedToolGate,
      qubit,
      step,
      targetQubit:
        computedTarget !== undefined && computedTarget !== qubit
          ? computedTarget
          : isTwoQubit
          ? (qubit + 1) % numQubits
          : undefined,
      angle: isRotation ? defaultAngle : undefined,
    };

    setGates((prev) => {
      const cleaned = prev.filter((g) => {
        if (g.step !== step) return true;
        if (g.qubit === qubit || g.targetQubit === qubit) return false;
        if (
          newGate.targetQubit !== undefined &&
          (g.qubit === newGate.targetQubit || g.targetQubit === newGate.targetQubit)
        ) {
          return false;
        }
        return true;
      });
      return [...cleaned, newGate];
    });
    setSelectedGateId(newId);
  };

  const handleUpdateSelectedGateAngle = (newAngle: number) => {
    setDefaultAngle(newAngle);
    if (!selectedGateId) return;
    setGates((prev) =>
      prev.map((g) => (g.id === selectedGateId ? { ...g, angle: newAngle } : g))
    );
  };

  const handleDeleteSelectedGate = () => {
    if (!selectedGateId) return;
    setGates((prev) => prev.filter((g) => g.id !== selectedGateId));
    setSelectedGateId(null);
  };

  // Top 16 basis states by probability or all if numQubits <= 4
  const visibleBasisStates =
    simulation.basisStates.length <= 16
      ? simulation.basisStates
      : [...simulation.basisStates]
          .sort((a, b) => b.probability - a.probability)
          .slice(0, 16)
          .sort((a, b) => a.index - b.index);

  const inspectedBasis =
    visibleBasisStates.find((b) => b.bitstring === hoveredBitstring) ||
    [...simulation.basisStates].sort((a, b) => b.probability - a.probability)[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Control & Parameter Column */}
      <aside className="lg:col-span-4 xl:col-span-3 bg-[#111827] border border-slate-800 p-5 space-y-6">
        {/* Domain Preset Library */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <h2 className="text-sm font-semibold text-slate-100 tracking-wide">
              Domain Benchmark Circuits
            </h2>
            <span className="text-xs font-mono text-slate-400 tabular-nums">
              {filteredPresets.length} presets
            </span>
          </div>

          {/* Interactive Filter Controls */}
          <div className="grid grid-cols-4 gap-1 p-1 bg-[#07090E] border border-slate-800/90 mb-3">
            {(['all', 'pharma', 'finance', 'research'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setDomainFilter(cat)}
                className={`py-1.5 px-2 text-xs font-medium capitalize transition-colors whitespace-nowrap ${
                  domainFilter === cat
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {filteredPresets.map((preset) => {
              const isSelected = activePreset.id === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    onSelectPreset(preset);
                    setSelectedGateId(null);
                  }}
                  className={`w-full text-left p-2.5 transition-colors border ${
                    isSelected
                      ? 'bg-cyan-950/30 border-cyan-500/50 text-slate-100'
                      : 'bg-[#0B0E17] border-slate-800/80 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-semibold text-slate-100 truncate">
                    {preset.name}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                    <span className="capitalize">{preset.domain}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{preset.numQubits}Q</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums truncate">
                      {preset.targetMetricValue}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <hr className="border-slate-800" />

        {/* Register & Shot Calibration */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-slate-100 tracking-wide">
            Register & Execution Parameters
          </h3>

          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Qubit Register Width</span>
              <span className="font-mono text-slate-200 tabular-nums">
                {numQubits} Qubits ({1 << numQubits} states)
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[3, 4, 5, 6].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setNumQubits(n)}
                  className={`py-1.5 px-3 text-xs font-mono tabular-nums border transition-colors whitespace-nowrap ${
                    numQubits === n
                      ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-semibold'
                      : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {n} Q
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Measurement Shots</span>
              <span className="font-mono text-slate-200 tabular-nums">
                {shots.toLocaleString()} shots
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {[1024, 4096, 8192].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShots(s)}
                  className={`py-1.5 px-2 text-xs font-mono tabular-nums border transition-colors whitespace-nowrap ${
                    shots === s
                      ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-semibold'
                      : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Decoherence & Gate Noise</span>
              <span className="font-mono text-slate-300">
                {useNoiseModel ? activeBackend.name : 'Exact Ideal'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setUseNoiseModel(false)}
                className={`py-1.5 px-3 text-xs font-medium border transition-colors whitespace-nowrap ${
                  !useNoiseModel
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                    : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Ideal Statevector
              </button>
              <button
                type="button"
                onClick={() => setUseNoiseModel(true)}
                className={`py-1.5 px-3 text-xs font-medium border transition-colors whitespace-nowrap ${
                  useNoiseModel
                    ? 'bg-amber-500/15 border-amber-500/60 text-amber-300'
                    : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                QPU Noise Model
              </button>
            </div>
          </div>
        </div>

        <hr className="border-slate-800" />

        {/* Unitary Gate Palette */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-100 tracking-wide">
              Unitary Gate Palette
            </h3>
            <span className="text-xs font-mono text-cyan-400">
              Active: {selectedToolGate}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {GATE_PALETTE.map((item) => {
              const active = selectedToolGate === item.type;
              return (
                <button
                  key={item.type}
                  type="button"
                  title={item.desc}
                  onClick={() => setSelectedToolGate(item.type)}
                  className={`py-2 px-2 text-xs font-mono font-semibold border transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                      : 'bg-[#0B0E17] text-slate-200 border-slate-800 hover:border-slate-600'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          {/* Rotation Angle Scrubber */}
          <div className="pt-2">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400 flex items-center gap-1">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Rotation Angle θ (rad)
              </span>
              <span className="font-mono text-cyan-300 tabular-nums">
                {(selectedGateObj?.angle ?? defaultAngle).toFixed(4)} rad (
                {(
                  ((selectedGateObj?.angle ?? defaultAngle) * 180) /
                  Math.PI
                ).toFixed(1)}
                °)
              </span>
            </div>
            <input
              type="range"
              min={-3.1416}
              max={3.1416}
              step={0.01}
              value={selectedGateObj?.angle ?? defaultAngle}
              onChange={(e) =>
                handleUpdateSelectedGateAngle(parseFloat(e.target.value))
              }
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500 tabular-nums">
              <span>-π</span>
              <span>-π/2</span>
              <span>0</span>
              <span>+π/2</span>
              <span>+π</span>
            </div>
          </div>

          {/* Two-qubit target stride selector */}
          {(selectedToolGate === 'CNOT' ||
            selectedToolGate === 'CZ' ||
            selectedToolGate === 'SWAP') && (
            <div className="pt-1">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Target Qubit Stride</span>
                <span className="font-mono text-slate-200 tabular-nums">
                  +{targetOffset} wire
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {[1, 2, 3].map((stride) => (
                  <button
                    key={stride}
                    type="button"
                    onClick={() => setTargetOffset(stride)}
                    className={`py-1 px-2 text-xs font-mono border whitespace-nowrap ${
                      targetOffset === stride
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                        : 'bg-[#0B0E17] border-slate-800 text-slate-400'
                    }`}
                  >
                    q + {stride}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <hr className="border-slate-800" />

        {/* Circuit Actions */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={onSubmitCloudJob}
            className="w-full py-2.5 px-4 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs tracking-wide transition-colors flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Dispatch to {activeBackend.name} Queue
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                onSelectPreset(activePreset);
                setSelectedGateId(null);
              }}
              className="py-2 px-3 bg-[#0B0E17] hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Preset
            </button>
            <button
              type="button"
              onClick={() => {
                setGates([]);
                setSelectedGateId(null);
              }}
              className="py-2 px-3 bg-[#0B0E17] hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 border border-slate-800 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Wires
            </button>
          </div>
        </div>
      </aside>

      {/* Main Viewport Stage */}
      <div className="lg:col-span-8 xl:col-span-9 space-y-6">
        {/* Preset Context & Live Telemetry Strip */}
        <section className="bg-[#111827] border border-slate-800 p-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span className="capitalize text-cyan-400 font-medium">
                  {activePreset.domain} Application
                </span>
                <span aria-hidden="true">·</span>
                <span>{activePreset.subtitle}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-slate-300">
                  {activePreset.referenceCitation}
                </span>
              </div>
              <h1 className="text-xl font-bold text-slate-100 mt-1 tracking-tight">
                {activePreset.name}
              </h1>
              <p className="text-sm text-slate-400 mt-1 max-w-3xl">
                {activePreset.description}
              </p>
            </div>

            <div className="shrink-0 text-left md:text-right border-t md:border-t-0 pt-3 md:pt-0 border-slate-800">
              <div className="text-xs text-slate-400">
                {activePreset.targetMetricLabel}
              </div>
              <div className="text-xl font-mono font-bold text-cyan-400 tabular-nums mt-0.5">
                {activePreset.targetMetricValue}
              </div>
              <div className="text-xs font-mono text-emerald-400 mt-0.5">
                ● NOMINAL · Est. Fidelity {(simulation.estimatedFidelity * 100).toFixed(2)}%
              </div>
            </div>
          </div>

          {/* 4-Metric Precision Readout Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-4">
            <div>
              <div className="text-xs text-slate-400">Circuit Depth & Layers</div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-slate-100 tabular-nums">
                  {simulation.circuitDepth}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  layers ({simulation.singleQubitGateCount} 1Q · {simulation.twoQubitGateCount} 2Q)
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Coherent Gate Duration</div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-slate-100 tabular-nums">
                  {simulation.estimatedDurationNs}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  ns (T₂ = {activeBackend.medianT2Us} μs)
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Bipartite Entanglement</div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-cyan-400 tabular-nums">
                  {simulation.entanglementEntropy.toFixed(3)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  S(ρ) bits
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Expected QPU Survival</div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-emerald-400 tabular-nums">
                  {(simulation.estimatedFidelity * 100).toFixed(2)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  % survival
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Quantum Circuit Composer Canvas */}
        <section className="bg-[#111827] border border-slate-800 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-100 tracking-wide">
                Interactive Quantum Register Composer
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Click any wire step intersection to place <span className="font-mono text-cyan-300">{selectedToolGate}</span> · Click an existing gate to inspect or click twice to delete.
              </p>
            </div>

            {selectedGateObj && (
              <div className="flex items-center gap-3 bg-[#07090E] border border-slate-800 px-3 py-1.5 text-xs">
                <span className="font-mono text-cyan-300">
                  Selected: {selectedGateObj.type} on q[{selectedGateObj.qubit}] (Step {selectedGateObj.step})
                  {selectedGateObj.angle !== undefined
                    ? ` · θ=${selectedGateObj.angle.toFixed(2)}`
                    : ''}
                </span>
                <button
                  type="button"
                  onClick={handleDeleteSelectedGate}
                  className="text-rose-400 hover:text-rose-300 font-medium whitespace-nowrap cursor-pointer"
                >
                  Remove Gate
                </button>
              </div>
            )}
          </div>

          {/* Wire Grid */}
          <div className="overflow-x-auto pb-2">
            <div className="min-w-[760px] bg-[#07090E] border border-slate-800/90 p-4">
              {/* Time step header indices */}
              <div className="grid grid-cols-12 gap-0 mb-2">
                <div className="col-span-1 text-[11px] font-mono text-slate-500">
                  WIRE / t
                </div>
                {Array.from({ length: TOTAL_STEPS }, (_, s) => (
                  <div
                    key={s}
                    className="col-span-1 text-center text-[11px] font-mono text-slate-500 tabular-nums"
                  >
                    t={s}
                  </div>
                ))}
              </div>

              {/* Qubit rows */}
              <div className="space-y-3 relative">
                {Array.from({ length: numQubits }, (_, q) => {
                  const bloch = simulation.blochVectors[q];
                  return (
                    <div
                      key={q}
                      className="grid grid-cols-12 items-center relative h-12"
                    >
                      {/* Qubit Label */}
                      <div className="col-span-1 pr-2 flex items-center justify-between">
                        <span className="font-mono text-xs font-semibold text-slate-200 tabular-nums">
                          q[{q}] |0⟩
                        </span>
                      </div>

                      {/* Horizontal quantum wire */}
                      <div className="col-span-11 relative h-full flex items-center">
                        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-[1px] bg-slate-800 pointer-events-none" />

                        <div className="grid grid-cols-11 w-full h-full relative z-10">
                          {Array.from({ length: TOTAL_STEPS }, (_, step) => {
                            const gateHere = gates.find(
                              (g) => g.qubit === q && g.step === step
                            );
                            const targetHere = gates.find(
                              (g) =>
                                g.step === step &&
                                g.targetQubit === q &&
                                g.qubit < numQubits
                            );

                            const isSelected =
                              (gateHere && gateHere.id === selectedGateId) ||
                              (targetHere && targetHere.id === selectedGateId);

                            // Calculate vertical connector bar if this is the control qubit of a 2-qubit gate
                            let connectorStyle: React.CSSProperties | null = null;
                            if (
                              gateHere &&
                              gateHere.targetQubit !== undefined &&
                              gateHere.targetQubit < numQubits
                            ) {
                              const deltaWires = gateHere.targetQubit - q;
                              const heightPx = Math.abs(deltaWires) * 60;
                              connectorStyle = {
                                height: `${heightPx}px`,
                                top: deltaWires > 0 ? '50%' : `${50 - heightPx}%`,
                              };
                            }

                            return (
                              <div
                                key={step}
                                className="relative flex items-center justify-center h-full"
                              >
                                {connectorStyle && (
                                  <div
                                    style={connectorStyle}
                                    className="w-[2px] bg-cyan-400/80 absolute left-1/2 -translate-x-1/2 pointer-events-none z-0"
                                  />
                                )}

                                <button
                                  type="button"
                                  onClick={() => handleCellClick(q, step)}
                                  title={
                                    gateHere
                                      ? `${gateHere.type} on q[${q}] at t=${step} (Click to select/remove)`
                                      : `Place ${selectedToolGate} on q[${q}] at t=${step}`
                                  }
                                  className={`relative z-10 w-10 h-9 flex flex-col items-center justify-center font-mono text-xs transition-all cursor-pointer ${
                                    gateHere
                                      ? isSelected
                                        ? 'bg-cyan-400 text-slate-950 font-bold ring-2 ring-cyan-200'
                                        : gateHere.type === 'CNOT' ||
                                          gateHere.type === 'CZ' ||
                                          gateHere.type === 'SWAP'
                                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/70 font-semibold'
                                        : gateHere.angle !== undefined
                                        ? 'bg-slate-900 text-amber-300 border border-amber-500/50 font-semibold'
                                        : 'bg-slate-900 text-slate-100 border border-slate-700 font-semibold'
                                      : targetHere
                                      ? 'bg-cyan-950/90 text-cyan-300 border border-cyan-400 font-bold rounded-full w-8 h-8'
                                      : 'bg-transparent hover:bg-slate-800/60 text-transparent hover:text-slate-400 border border-transparent hover:border-slate-700'
                                  }`}
                                >
                                  {gateHere ? (
                                    <>
                                      <span className="leading-none">
                                        {gateHere.type === 'CNOT'
                                          ? '● CX'
                                          : gateHere.type === 'CZ'
                                          ? '● CZ'
                                          : gateHere.type}
                                      </span>
                                      {gateHere.angle !== undefined && (
                                        <span className="text-[9px] leading-none mt-0.5 opacity-85 tabular-nums">
                                          {gateHere.angle.toFixed(2)}
                                        </span>
                                      )}
                                    </>
                                  ) : targetHere ? (
                                    <span>
                                      {targetHere.type === 'CNOT'
                                        ? '⊕'
                                        : targetHere.type === 'CZ'
                                        ? 'Z'
                                        : '×'}
                                    </span>
                                  ) : (
                                    <Plus className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Right marginal readout */}
                      <span className="sr-only">
                        P(|1⟩) = {(bloch?.p1 ?? 0).toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Single-Qubit Bloch Vectors & Marginal Readouts */}
          <div className="mt-5 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Single-Qubit Reduced Density Matrix & Bloch Coordinates
              </h3>
              <span className="text-xs font-mono text-slate-400">
                Purity Tr(ρ²) &lt; 1.000 indicates bipartite entanglement
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
              {simulation.blochVectors.map((bv) => (
                <div
                  key={bv.qubit}
                  className="bg-[#0B0E17] border border-slate-800/90 p-3 flex items-center gap-3"
                >
                  {/* Mini SVG Bloch Projection */}
                  <svg
                    viewBox="-1.25 -1.25 2.5 2.5"
                    className="w-11 h-11 shrink-0 overflow-visible"
                  >
                    <circle
                      cx="0"
                      cy="0"
                      r="1"
                      fill="none"
                      stroke="#334155"
                      strokeWidth="0.08"
                    />
                    <ellipse
                      cx="0"
                      cy="0"
                      rx="1"
                      ry="0.35"
                      fill="none"
                      stroke="#1E293B"
                      strokeWidth="0.07"
                      strokeDasharray="0.12 0.12"
                    />
                    <line
                      x1="0"
                      y1="-1"
                      x2="0"
                      y2="1"
                      stroke="#1E293B"
                      strokeWidth="0.07"
                    />
                    {/* Bloch Vector projected onto (x, -z) plane */}
                    <line
                      x1="0"
                      y1="0"
                      x2={bv.x}
                      y2={-bv.z}
                      stroke="#06B6D4"
                      strokeWidth="0.14"
                    />
                    <circle
                      cx={bv.x}
                      cy={-bv.z}
                      r="0.16"
                      fill="#22D3EE"
                    />
                  </svg>

                  <div className="min-w-0 flex-1 font-mono text-[11px] tabular-nums">
                    <div className="font-semibold text-slate-200 flex items-center justify-between">
                      <span>q[{bv.qubit}]</span>
                      <span className="text-cyan-400">
                        P₁={(bv.p1 * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="text-slate-400 truncate mt-0.5">
                      ⟨Z⟩ {bv.z >= 0 ? `+${bv.z.toFixed(2)}` : bv.z.toFixed(2)} · ⟨X⟩{' '}
                      {bv.x >= 0 ? `+${bv.x.toFixed(2)}` : bv.x.toFixed(2)}
                    </div>
                    <div className="text-slate-500 mt-0.5">
                      Tr(ρ²) = {bv.purity.toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Bottom Measurement Probability & Complex Amplitude Telemetry Tray */}
        <section className="bg-[#111827] border border-slate-800 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-100 tracking-wide">
                Computational Basis Statevector & Quasi-Probability Distribution
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Hover any computational basis bar to inspect exact complex amplitude ψ = α + iβ, phase angle φ, and hardware shot counts.
              </p>
            </div>

            {inspectedBasis && (
              <div className="bg-[#07090E] border border-slate-800 px-3.5 py-2 font-mono text-xs tabular-nums flex items-center gap-3">
                <span className="text-cyan-400 font-semibold">
                  |{inspectedBasis.bitstring}⟩
                </span>
                <span aria-hidden="true" className="text-slate-600">
                  ·
                </span>
                <span className="text-slate-200">
                  P = {(inspectedBasis.probability * 100).toFixed(2)}%
                </span>
                <span aria-hidden="true" className="text-slate-600">
                  ·
                </span>
                <span className="text-slate-300">
                  ψ = {inspectedBasis.amplitude.re >= 0 ? '+' : ''}
                  {inspectedBasis.amplitude.re.toFixed(3)}{' '}
                  {inspectedBasis.amplitude.im >= 0 ? '+' : '-'} i
                  {Math.abs(inspectedBasis.amplitude.im).toFixed(3)}
                </span>
                <span aria-hidden="true" className="text-slate-600">
                  ·
                </span>
                <span className="text-amber-300">
                  {useNoiseModel
                    ? `${inspectedBasis.noisyShots} noisy shots`
                    : `${inspectedBasis.idealShots} ideal shots`}
                </span>
              </div>
            )}
          </div>

          {/* Bar Histogram */}
          <div className="h-52 bg-[#07090E] border border-slate-800/90 p-4 flex items-end gap-2 cursor-crosshair">
            {visibleBasisStates.map((b) => {
              const idealHeightPct = Math.max(1.5, b.probability * 100);
              const noisyProb = b.noisyShots / shots;
              const noisyHeightPct = Math.max(1.5, noisyProb * 100);
              const isHovered = inspectedBasis?.bitstring === b.bitstring;

              return (
                <div
                  key={b.bitstring}
                  onMouseEnter={() => setHoveredBitstring(b.bitstring)}
                  className="flex-1 h-full flex flex-col justify-end items-center group"
                >
                  <div className="w-full text-center font-mono text-[10px] text-slate-400 tabular-nums mb-1 opacity-85 group-hover:text-cyan-300">
                    {( (useNoiseModel ? noisyProb : b.probability) * 100 ).toFixed(1)}%
                  </div>

                  <div className="w-full h-36 flex items-end justify-center gap-1 border-b border-slate-800 pb-0.5">
                    {/* Ideal statevector bar */}
                    <div
                      style={{ height: `${Math.min(100, idealHeightPct)}%` }}
                      className={`w-full max-w-[22px] transition-opacity ${
                        isHovered ? 'bg-cyan-400' : 'bg-cyan-500/80'
                      }`}
                    />
                    {/* Optional Hardware Noise Comparison Bar */}
                    {useNoiseModel && (
                      <div
                        style={{ height: `${Math.min(100, noisyHeightPct)}%` }}
                        className="w-full max-w-[14px] bg-amber-500/85"
                      />
                    )}
                  </div>

                  <div
                    className={`mt-2 font-mono text-[11px] tabular-nums ${
                      isHovered
                        ? 'text-cyan-300 font-semibold'
                        : 'text-slate-400'
                    }`}
                  >
                    |{b.bitstring}⟩
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-400 font-mono">
            <div className="flex items-center gap-4">
              <span>■ Cyan: Exact Statevector Probability |ψ|²</span>
              {useNoiseModel && (
                <span className="text-amber-400">
                  ■ Amber: {activeBackend.name} Depolarizing & Readout Sampled Shots
                </span>
              )}
            </div>
            <span>
              Hilbert Space Dimension: 2^{numQubits} = {1 << numQubits} Complex Amplitudes
            </span>
          </div>
        </section>
      </div>
    </div>
  );
};
