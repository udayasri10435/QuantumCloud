import React, { useState } from 'react';
import {
  CircuitGate,
  CircuitPreset,
  QuantumBackend,
  SimulationResult,
  generateOpenQasm3,
  generatePythonSdkCode,
} from '../lib/quantumEngine';
import { Copy, Check, Download, Terminal } from 'lucide-react';

interface SdkTranspilerViewProps {
  numQubits: number;
  gates: CircuitGate[];
  shots: number;
  activeBackend: QuantumBackend;
  activePreset: CircuitPreset;
  simulation: SimulationResult;
}

type CodeTab = 'python-sdk' | 'openqasm3' | 'pennylane' | 'rest-json';

export const SdkTranspilerView: React.FC<SdkTranspilerViewProps> = ({
  numQubits,
  gates,
  shots,
  activeBackend,
  activePreset,
  simulation,
}) => {
  const [optLevel, setOptLevel] = useState<0 | 1 | 2 | 3>(2);
  const [activeTab, setActiveTab] = useState<CodeTab>('python-sdk');
  const [copied, setCopied] = useState<boolean>(false);

  // Compute transpiler optimization telemetry based on optLevel and backend connectivity
  const connectivityFactor =
    activeBackend.modality === 'Trapped-Ion' ||
    activeBackend.modality === 'Tensor-GPU'
      ? 0
      : activeBackend.modality === 'Neutral-Atom'
      ? 1
      : 2;

  const rawSwaps = simulation.twoQubitGateCount * connectivityFactor;
  const routedSwaps =
    optLevel === 0
      ? rawSwaps
      : optLevel === 1
      ? Math.ceil(rawSwaps * 0.75)
      : optLevel === 2
      ? Math.ceil(rawSwaps * 0.4)
      : Math.floor(rawSwaps * 0.2);

  const nativeRzCount =
    simulation.singleQubitGateCount * (optLevel >= 2 ? 2 : 3) +
    routedSwaps * 2;
  const nativeSxCount =
    simulation.singleQubitGateCount * (optLevel >= 3 ? 1 : 2) +
    routedSwaps * 2;
  const nativeCzCount = simulation.twoQubitGateCount + routedSwaps * 3;
  const compiledDepth =
    Math.max(1, simulation.circuitDepth + routedSwaps * 2 - (optLevel >= 2 ? 2 : 0));

  const codeContent = React.useMemo(() => {
    if (activeTab === 'openqasm3') {
      return generateOpenQasm3(numQubits, gates, activeBackend, optLevel);
    }
    if (activeTab === 'python-sdk') {
      return generatePythonSdkCode(
        numQubits,
        gates,
        activeBackend,
        shots,
        optLevel
      );
    }
    if (activeTab === 'pennylane') {
      return [
        'import pennylane as qml',
        'from pennylane import numpy as np',
        '',
        `# Target Veritas Cloud QPU via PennyLane Plugin (${activeBackend.name})`,
        `dev = qml.device("veritas.cloud", backend="${activeBackend.id}", wires=${numQubits}, shots=${shots})`,
        '',
        '@qml.qnode(dev, diff_method="parameter-shift")',
        'def variational_circuit(theta):',
        ...gates
          .slice(0, 8)
          .map((g, idx) =>
            g.targetQubit !== undefined
              ? `    qml.${g.type}([${g.qubit}, ${g.targetQubit % numQubits}])`
              : g.angle !== undefined
              ? `    qml.${g.type}(theta[${idx}], wires=${g.qubit})`
              : `    qml.${g.type === 'H' ? 'Hadamard' : `Pauli${g.type}`}(wires=${g.qubit})`
          ),
        `    return qml.expval(qml.PauliZ(0) @ qml.PauliZ(1))`,
        '',
        `params = np.array([${gates
          .slice(0, 8)
          .map((g) => (g.angle ?? 0.52).toFixed(3))
          .join(', ')}], requires_grad=True)`,
        'opt = qml.AdamOptimizer(stepsize=0.04)',
        'for epoch in range(25):',
        '    params, cost = opt.step_and_cost(variational_circuit, params)',
      ].join('\n');
    }
    return JSON.stringify(
      {
        apiVersion: 'quantum.veritas.cloud/v1',
        preset: activePreset.id,
        domain: activePreset.domain,
        targetBackend: activeBackend.id,
        transpiler: {
          optimizationLevel: optLevel,
          routingMethod: optLevel >= 2 ? 'SABRE-Stochastic' : 'Trivial-Layout',
          dynamicalDecoupling: 'XY4-Symmetric',
          nativeBasisGates: ['rz', 'sx', 'x', 'cz'],
        },
        execution: {
          shots,
          readoutMitigation: 'M3-Matrix-Free',
        },
        registerWidth: numQubits,
        operations: gates.map((g) => ({
          op: g.type.toLowerCase(),
          qubits:
            g.targetQubit !== undefined ? [g.qubit, g.targetQubit] : [g.qubit],
          params: g.angle !== undefined ? [Number(g.angle.toFixed(4))] : [],
          cycle: g.step,
        })),
      },
      null,
      2
    );
  }, [activeTab, numQubits, gates, activeBackend, shots, optLevel, activePreset]);

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownload = () => {
    const ext =
      activeTab === 'openqasm3'
        ? 'qasm'
        : activeTab === 'rest-json'
        ? 'json'
        : 'py';
    const blob = new Blob([codeContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activePreset.id}-O${optLevel}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left 4 Cols: Transpiler Pass Manager & Native Gate Decomposition */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-[#111827] border border-slate-800 p-5 space-y-4">
          <div>
            <div className="text-xs text-slate-400">
              Hardware-Aware Compiler Pipeline
            </div>
            <h2 className="text-lg font-bold text-slate-100 mt-0.5">
              Transpiler Optimization Passes
            </h2>
          </div>

          <div className="space-y-2">
            {(
              [
                {
                  lvl: 0 as const,
                  title: 'Level O0 · Trivial Wire Mapping',
                  desc: 'Direct 1:1 virtual-to-physical qubit assignment without gate cancellation.',
                },
                {
                  lvl: 1 as const,
                  title: 'Level O1 · Inverse Gate Cancellation',
                  desc: 'Merges adjacent single-qubit Euler Z-X-Z rotations and cancels H·H / CX·CX pairs.',
                },
                {
                  lvl: 2 as const,
                  title: 'Level O2 · Noise-Adaptive SABRE Routing',
                  desc: 'Routes two-qubit gates across highest-fidelity couplers and minimizes SWAP depth.',
                },
                {
                  lvl: 3 as const,
                  title: 'Level O3 · KAK SU(4) Unitary Synthesis',
                  desc: 'Resynthesizes two-qubit blocks via Cartan KAK decomposition + XY4 dynamical decoupling.',
                },
              ] as const
            ).map((item) => {
              const active = optLevel === item.lvl;
              return (
                <button
                  key={item.lvl}
                  type="button"
                  onClick={() => setOptLevel(item.lvl)}
                  className={`w-full text-left p-3 border transition-colors cursor-pointer ${
                    active
                      ? 'bg-cyan-950/30 border-cyan-500/60 text-slate-100'
                      : 'bg-[#0B0E17] border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-mono font-semibold text-cyan-300">
                    {item.title}
                  </div>
                  <div className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {item.desc}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Native Hardware Basis Gate Breakdown */}
        <div className="bg-[#111827] border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-100">
              Compiled Native Basis Decomposition
            </h3>
            <span className="text-xs font-mono text-cyan-400">
              {activeBackend.name}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-1 font-mono tabular-nums">
            <div className="border-b border-slate-800 pb-2.5">
              <div className="text-[11px] text-slate-400">VIRTUAL RZ GATES</div>
              <div className="text-xl font-bold text-slate-100 mt-0.5">
                {nativeRzCount}{' '}
                <span className="text-xs font-normal text-emerald-400">
                  (0 ns frame)
                </span>
              </div>
            </div>

            <div className="border-b border-slate-800 pb-2.5">
              <div className="text-[11px] text-slate-400">PHYSICAL √X (SX)</div>
              <div className="text-xl font-bold text-slate-100 mt-0.5">
                {nativeSxCount}
              </div>
            </div>

            <div className="border-b border-slate-800 pb-2.5">
              <div className="text-[11px] text-slate-400">NATIVE 2Q CZ / CX</div>
              <div className="text-xl font-bold text-cyan-400 mt-0.5">
                {nativeCzCount}
              </div>
            </div>

            <div className="border-b border-slate-800 pb-2.5">
              <div className="text-[11px] text-slate-400">INSERTED SWAPS</div>
              <div className="text-xl font-bold text-amber-400 mt-0.5">
                {routedSwaps}
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400 flex items-center justify-between pt-1">
            <span>Compiled Physical Schedule Depth</span>
            <span className="font-mono font-semibold text-slate-200 tabular-nums">
              {compiledDepth} cycles ({compiledDepth * activeBackend.gateTime2QNs} ns)
            </span>
          </div>
        </div>
      </div>

      {/* Right 8 Cols: Live Multi-Language Code Inspector */}
      <div className="lg:col-span-8 bg-[#111827] border border-slate-800">
        <div className="px-5 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 bg-[#07090E] p-1 border border-slate-800">
            {(
              [
                { id: 'python-sdk', label: 'Veritas Python SDK' },
                { id: 'openqasm3', label: 'OpenQASM 3.0' },
                { id: 'pennylane', label: 'PennyLane Hybrid' },
                { id: 'rest-json', label: 'Cloud gRPC / JSON' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 text-xs font-mono transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="px-3 py-1.5 bg-[#0B0E17] hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-200 flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Copy Source</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleDownload}
              className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export File</span>
            </button>
          </div>
        </div>

        {/* Code Display */}
        <div className="p-5 bg-[#07090E] overflow-x-auto">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 pb-3 mb-3 border-b border-slate-800/80">
            <span className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              Synchronized with Studio Circuit: {activePreset.name} ({numQubits} Qubits · {gates.length} Operations)
            </span>
            <span>UTF-8 · Tabular Monospace</span>
          </div>

          <pre className="font-mono text-xs leading-relaxed text-slate-200 select-all">
            <code>{codeContent}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
