import React, { useState, useEffect } from 'react';
import {
  HYBRID_WORKFLOW_PRESETS,
  HybridWorkflowPreset,
  QuantumBackend,
} from '../lib/quantumEngine';
import pharmaImg from '../assets/images/pharma_ligand_binding_1790671141214.jpg';
import financeImg from '../assets/images/finance_quantum_surface_1790671152655.jpg';
import researchImg from '../assets/images/qpu_cryostat_hardware_1790671129625.jpg';
import { Play, RotateCcw, Activity } from 'lucide-react';

interface HybridWorkflowsViewProps {
  activeBackend: QuantumBackend;
  onLogWorkflowJob: (workflow: HybridWorkflowPreset, finalVal: number) => void;
}

type OptimizerType = 'L-BFGS-B' | 'SPSA' | 'COBYLA' | 'Adam-Shift';
type MitigationType = 'ZNE (Richardsons)' | 'PEC (Quasi-Prob)' | 'Readout-Twirl';

interface IterationPoint {
  step: number;
  mitigatedValue: number;
  rawNoisyValue: number;
  gradientNorm: number;
}

export const HybridWorkflowsView: React.FC<HybridWorkflowsViewProps> = ({
  activeBackend,
  onLogWorkflowJob,
}) => {
  const [selectedWorkflow, setSelectedWorkflow] = useState<HybridWorkflowPreset>(
    HYBRID_WORKFLOW_PRESETS[0]
  );
  const [optimizer, setOptimizer] = useState<OptimizerType>('L-BFGS-B');
  const [mitigation, setMitigation] = useState<MitigationType>('ZNE (Richardsons)');
  const [ansatzLayers, setAnsatzLayers] = useState<number>(3);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentIteration, setCurrentIteration] = useState<number>(24);
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);
  const [imgError, setImgError] = useState<boolean>(false);

  const totalSteps = 24;

  // Generate deterministic convergence trajectory based on workflow, optimizer, layers, and mitigation
  const trajectory: IterationPoint[] = React.useMemo(() => {
    const pts: IterationPoint[] = [];
    const span = selectedWorkflow.initialValue - selectedWorkflow.exactReferenceValue;
    const rate =
      optimizer === 'L-BFGS-B'
        ? 0.22
        : optimizer === 'Adam-Shift'
        ? 0.19
        : optimizer === 'COBYLA'
        ? 0.16
        : 0.14;
    const layerBonus = Math.min(1.0, 0.78 + ansatzLayers * 0.05);
    const mitigationResidual =
      mitigation === 'PEC (Quasi-Prob)'
        ? 0.0012
        : mitigation === 'ZNE (Richardsons)'
        ? 0.0025
        : 0.014;

    for (let k = 0; k <= totalSteps; k++) {
      const decay = Math.exp(-rate * k * layerBonus);
      const osc = Math.sin(k * 1.3) * 0.015 * decay;
      const mitigatedDelta = span * (decay + osc + mitigationResidual * (1 - decay));
      const rawNoiseFloor = span * (decay * 1.12 + 0.065 + Math.cos(k * 1.7) * 0.012);

      const mitigatedValue = Number(
        (selectedWorkflow.exactReferenceValue + mitigatedDelta).toFixed(4)
      );
      const rawNoisyValue = Number(
        (selectedWorkflow.exactReferenceValue + rawNoiseFloor).toFixed(4)
      );
      const gradientNorm = Number(
        Math.max(0.0004, Math.abs(span) * 0.45 * decay).toFixed(4)
      );

      pts.push({
        step: k,
        mitigatedValue,
        rawNoisyValue,
        gradientNorm,
      });
    }
    return pts;
  }, [selectedWorkflow, optimizer, ansatzLayers, mitigation]);

  useEffect(() => {
    if (!isRunning) return;
    if (currentIteration >= totalSteps) {
      setIsRunning(false);
      const last = trajectory[trajectory.length - 1];
      if (last) {
        onLogWorkflowJob(selectedWorkflow, last.mitigatedValue);
      }
      return;
    }
    const timer = setTimeout(() => {
      setCurrentIteration((prev) => Math.min(totalSteps, prev + 1));
    }, 95);
    return () => clearTimeout(timer);
  }, [isRunning, currentIteration, trajectory, selectedWorkflow, onLogWorkflowJob]);

  const handleStartConvergence = () => {
    setCurrentIteration(1);
    setIsRunning(true);
  };

  const visibleTrajectory = trajectory.slice(0, currentIteration + 1);
  const activePoint =
    (hoveredStep !== null ? visibleTrajectory.find((p) => p.step === hoveredStep) : null) ||
    visibleTrajectory[visibleTrajectory.length - 1] ||
    trajectory[0];

  const absError = Math.abs(
    activePoint.mitigatedValue - selectedWorkflow.exactReferenceValue
  );
  const withinChemicalOrRegThreshold =
    absError <= selectedWorkflow.convergenceThreshold * 2.2;

  const domainImageSrc =
    selectedWorkflow.domain === 'pharma'
      ? pharmaImg
      : selectedWorkflow.domain === 'finance'
      ? financeImg
      : researchImg;

  // SVG Chart Geometry
  const svgW = 680;
  const svgH = 250;
  const padL = 56;
  const padR = 24;
  const padT = 20;
  const padB = 34;
  const plotW = svgW - padL - padR;
  const plotH = svgH - padT - padB;

  const allValues = trajectory.flatMap((p) => [
    p.mitigatedValue,
    p.rawNoisyValue,
    selectedWorkflow.exactReferenceValue,
  ]);
  const minVal = Math.min(...allValues);
  const maxVal = Math.max(...allValues);
  const valRange = Math.max(1e-6, maxVal - minVal);

  const toX = (step: number) => padL + (step / totalSteps) * plotW;
  const toY = (val: number) =>
    padT + plotH - ((val - minVal) / valRange) * plotH;

  const mitigatedPolyline = visibleTrajectory
    .map((p) => `${toX(p.step).toFixed(1)},${toY(p.mitigatedValue).toFixed(1)}`)
    .join(' ');

  const rawPolyline = visibleTrajectory
    .map((p) => `${toX(p.step).toFixed(1)},${toY(p.rawNoisyValue).toFixed(1)}`)
    .join(' ');

  const exactY = toY(selectedWorkflow.exactReferenceValue);

  return (
    <div className="space-y-6">
      {/* Workflow Selection Header */}
      <div className="bg-[#111827] border border-slate-800 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>Hybrid Quantum-Classical Co-Processing</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-cyan-400">
              QPU: {activeBackend.name} + CPU/GPU Parameter Server
            </span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 mt-1">
            Variational Eigensolvers, Amplitude Estimation & Trotter Workflows
          </h1>
        </div>

        {/* 3 Flagship Domain Workflow Selector Tabs */}
        <div className="flex flex-wrap gap-1.5 bg-[#07090E] p-1.5 border border-slate-800">
          {HYBRID_WORKFLOW_PRESETS.map((wf) => {
            const active = wf.id === selectedWorkflow.id;
            return (
              <button
                key={wf.id}
                type="button"
                onClick={() => {
                  setSelectedWorkflow(wf);
                  setCurrentIteration(totalSteps);
                  setIsRunning(false);
                  setImgError(false);
                }}
                className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/50'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                <span className="uppercase font-mono text-[10px] mr-1.5 opacity-75">
                  [{wf.domain}]
                </span>
                {wf.algorithm}: {wf.name.split(' ')[0]} {wf.name.split(' ')[1]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Split Console: Left Parameter & Visual Card + Right Convergence & Hamiltonian */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 4 Cols: Classical Optimizer Controls & Domain Visual */}
        <div className="lg:col-span-4 space-y-6">
          {/* Domain System Visual Card */}
          <div className="bg-[#111827] border border-slate-800 overflow-hidden">
            <div className="relative h-48 bg-[#07090E] border-b border-slate-800">
              {!imgError ? (
                <img
                  src={domainImageSrc}
                  alt={selectedWorkflow.name}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover opacity-90"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-slate-950">
                  <Activity className="w-8 h-8 text-cyan-400 mb-2" />
                  <span className="text-xs font-mono text-slate-300">
                    {selectedWorkflow.targetSystem}
                  </span>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent flex flex-col justify-end p-4">
                <div className="text-xs font-mono text-cyan-300 uppercase">
                  {selectedWorkflow.domain} · {selectedWorkflow.algorithm} Pipeline
                </div>
                <div className="text-base font-bold text-white mt-0.5">
                  {selectedWorkflow.name}
                </div>
              </div>
            </div>

            <div className="p-5 space-y-3">
              <div className="text-xs text-slate-400">
                Target System: <span className="text-slate-200">{selectedWorkflow.targetSystem}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedWorkflow.description}
              </p>
              <div className="pt-2 border-t border-slate-800 text-xs text-emerald-400 leading-relaxed">
                Benchmark Outcome: {selectedWorkflow.clinicalOrFinancialImpact}
              </div>
            </div>
          </div>

          {/* Hybrid Loop Hyperparameters */}
          <div className="bg-[#111827] border border-slate-800 p-5 space-y-4">
            <h2 className="text-sm font-semibold text-slate-100">
              Variational Loop & Error Mitigation Controls
            </h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">
                Classical Parameter Optimizer
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {(['L-BFGS-B', 'Adam-Shift', 'SPSA', 'COBYLA'] as OptimizerType[]).map(
                  (opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setOptimizer(opt)}
                      className={`py-1.5 px-2.5 text-xs font-mono border transition-colors whitespace-nowrap cursor-pointer ${
                        optimizer === opt
                          ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-semibold'
                          : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {opt}
                    </button>
                  )
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">
                Quantum Error Mitigation Protocol
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {(
                  [
                    'ZNE (Richardsons)',
                    'PEC (Quasi-Prob)',
                    'Readout-Twirl',
                  ] as MitigationType[]
                ).map((mit) => (
                  <button
                    key={mit}
                    type="button"
                    onClick={() => setMitigation(mit)}
                    className={`py-1.5 px-3 text-left text-xs font-mono border transition-colors flex items-center justify-between cursor-pointer ${
                      mitigation === mit
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-semibold'
                        : 'bg-[#0B0E17] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span>{mit}</span>
                    <span className="text-[10px] opacity-80">
                      {mit === 'PEC (Quasi-Prob)'
                        ? 'Unbiased · 9x Shots'
                        : mit === 'ZNE (Richardsons)'
                        ? '1x, 3x, 5x Gate Folding'
                        : 'Pauli Bit-Flip Calibration'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Ansatz Repetition Depth (p)</span>
                <span className="font-mono text-cyan-300 tabular-nums">
                  p = {ansatzLayers} layers ({ansatzLayers * 18} parameters)
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={6}
                step={1}
                value={ansatzLayers}
                onChange={(e) => setAnsatzLayers(parseInt(e.target.value, 10))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleStartConvergence}
                disabled={isRunning}
                className="flex-1 py-2.5 px-4 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-semibold text-xs flex items-center justify-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                {isRunning
                  ? `Executing Iteration ${currentIteration}/${totalSteps}...`
                  : 'Run Hybrid Convergence Loop'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsRunning(false);
                  setCurrentIteration(totalSteps);
                }}
                title="Jump to final iteration"
                className="py-2.5 px-3 bg-[#0B0E17] hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-mono cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Right 8 Cols: Dual-Curve Convergence Chart & Hamiltonian Pauli Table */}
        <div className="lg:col-span-8 space-y-6">
          {/* Telemetry Metric Summary Row */}
          <div className="bg-[#111827] border border-slate-800 p-5 grid grid-cols-2 sm:grid-cols-4 gap-6">
            <div>
              <div className="text-xs text-slate-400">
                Mitigated Expectation
              </div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-bold text-cyan-400 tabular-nums">
                  {activePoint.mitigatedValue.toFixed(4)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  {selectedWorkflow.unit}
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">
                Exact Reference Target
              </div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-slate-100 tabular-nums">
                  {selectedWorkflow.exactReferenceValue.toFixed(4)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  {selectedWorkflow.unit}
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Residual Error |Δ|</div>
              <div className="mt-1 flex items-baseline">
                <span
                  className={`text-2xl font-mono font-semibold tabular-nums ${
                    withinChemicalOrRegThreshold
                      ? 'text-emerald-400'
                      : 'text-amber-400'
                  }`}
                >
                  {absError.toFixed(4)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  {selectedWorkflow.unit}
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Parameter Gradient ‖∇θ‖</div>
              <div className="mt-1 flex items-baseline">
                <span className="text-2xl font-mono font-semibold text-slate-200 tabular-nums">
                  {activePoint.gradientNorm.toFixed(4)}
                </span>
                <span className="text-xs font-mono text-slate-400 ml-1.5">
                  k={activePoint.step}/{totalSteps}
                </span>
              </div>
            </div>
          </div>

          {/* Dual-Curve Convergence Trajectory SVG */}
          <div className="bg-[#111827] border border-slate-800 p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Variational Objective Convergence Trajectory ({optimizer} + {mitigation})
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Hover across variational epochs to compare ZNE/PEC error-mitigated QPU expectation against raw unmitigated hardware readout.
                </p>
              </div>
              <span className="text-xs font-mono text-emerald-400 whitespace-nowrap">
                ● {selectedWorkflow.thresholdLabel}
              </span>
            </div>

            <div className="bg-[#07090E] border border-slate-800/90 p-3">
              <svg
                viewBox={`0 0 ${svgW} ${svgH}`}
                className="w-full h-64 select-none cursor-crosshair"
                onMouseLeave={() => setHoveredStep(null)}
              >
                {/* Horizontal Reference Grid Lines */}
                {[0, 0.25, 0.5, 0.75, 1].map((t) => {
                  const y = padT + t * plotH;
                  const val = maxVal - t * valRange;
                  return (
                    <g key={t}>
                      <line
                        x1={padL}
                        y1={y}
                        x2={svgW - padR}
                        y2={y}
                        stroke="#1E293B"
                        strokeWidth="1"
                      />
                      <text
                        x={padL - 8}
                        y={y + 3}
                        textAnchor="end"
                        className="font-mono text-[10px] fill-slate-500"
                      >
                        {val.toFixed(2)}
                      </text>
                    </g>
                  );
                })}

                {/* Exact Reference Target Line */}
                <line
                  x1={padL}
                  y1={exactY}
                  x2={svgW - padR}
                  y2={exactY}
                  stroke="#10B981"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />
                <text
                  x={svgW - padR - 6}
                  y={exactY - 6}
                  textAnchor="end"
                  className="font-mono text-[10px] fill-emerald-400"
                >
                  Exact Target: {selectedWorkflow.exactReferenceValue.toFixed(4)}{' '}
                  {selectedWorkflow.unit}
                </text>

                {/* Raw Noisy QPU Curve (Dashed Amber) */}
                {visibleTrajectory.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#F59E0B"
                    strokeWidth="1.8"
                    strokeDasharray="5 4"
                    points={rawPolyline}
                  />
                )}

                {/* Mitigated QPU Curve (Solid Cyan) */}
                {visibleTrajectory.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#06B6D4"
                    strokeWidth="2.5"
                    points={mitigatedPolyline}
                  />
                )}

                {/* Interactive Crosshair & Vertex Dots */}
                {visibleTrajectory.map((pt) => {
                  const cx = toX(pt.step);
                  const cy = toY(pt.mitigatedValue);
                  const isHovered = activePoint.step === pt.step;
                  return (
                    <g
                      key={pt.step}
                      onMouseEnter={() => setHoveredStep(pt.step)}
                    >
                      {isHovered && (
                        <line
                          x1={cx}
                          y1={padT}
                          x2={cx}
                          y2={svgH - padB}
                          stroke="#38BDF8"
                          strokeWidth="1"
                          strokeDasharray="2 2"
                        />
                      )}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isHovered ? 5 : 3}
                        fill={isHovered ? '#22D3EE' : '#06B6D4'}
                      />
                      {/* Invisible wider hit column for smooth scrubbing */}
                      <rect
                        x={cx - plotW / totalSteps / 2}
                        y={padT}
                        width={plotW / totalSteps}
                        height={plotH}
                        fill="transparent"
                      />
                    </g>
                  );
                })}

                {/* X-Axis Iteration Labels */}
                {[0, 4, 8, 12, 16, 20, 24].map((st) => (
                  <text
                    key={st}
                    x={toX(st)}
                    y={svgH - 10}
                    textAnchor="middle"
                    className="font-mono text-[10px] fill-slate-400"
                  >
                    Iter {st}
                  </text>
                ))}
              </svg>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-slate-400">
              <div className="flex items-center gap-5">
                <span className="text-cyan-400">
                  — Solid Cyan: {mitigation} Mitigated QPU
                </span>
                <span className="text-amber-400">
                  -- Dashed Amber: Raw Unmitigated QPU Readout
                </span>
              </div>
              <span>
                Inspecting Iteration k={activePoint.step} · Mitigated:{' '}
                {activePoint.mitigatedValue.toFixed(4)} vs Raw:{' '}
                {activePoint.rawNoisyValue.toFixed(4)}
              </span>
            </div>
          </div>

          {/* Hamiltonian Pauli Decomposition Table */}
          <div className="bg-[#111827] border border-slate-800">
            <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-slate-100">
                  Observable Hamiltonian Pauli Decomposition (Top Weighted Terms)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  H = Σ c_k P_k · {selectedWorkflow.hamiltonianTerms} total commuting Pauli tensor groups measured per epoch
                </p>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Ansatz: {selectedWorkflow.ansatzName}
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                <thead>
                  <tr className="border-b border-slate-800 bg-[#0B0E17] text-slate-400 text-[11px]">
                    <th className="py-2.5 px-5">INDEX</th>
                    <th className="py-2.5 px-4">PAULI TENSOR STRING P_k</th>
                    <th className="py-2.5 px-4 text-right">COEFFICIENT c_k</th>
                    <th className="py-2.5 px-5 text-right">MEASUREMENT BASIS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {selectedWorkflow.pauliDecomposition.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-5 text-slate-500">
                        Term #{idx + 1}
                      </td>
                      <td className="py-2.5 px-4 text-cyan-300 font-semibold">
                        {item.term}
                      </td>
                      <td className="py-2.5 px-4 text-right text-slate-100">
                        {item.coeff >= 0
                          ? `+${item.coeff.toFixed(5)}`
                          : item.coeff.toFixed(5)}
                      </td>
                      <td className="py-2.5 px-5 text-right text-slate-400">
                        {item.term.includes('X') || item.term.includes('Y')
                          ? 'Entangled Bell / Hadamard Rotated'
                          : 'Computational Z-Basis'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
