import React, { useState } from 'react';
import { QUANTUM_BACKENDS, QuantumBackend } from '../lib/quantumEngine';
import cryostatImg from '../assets/images/qpu_cryostat_hardware_1790671129625.jpg';
import { Check, Cpu } from 'lucide-react';

interface QuantumBackendsViewProps {
  activeBackend: QuantumBackend;
  onSelectBackend: (b: QuantumBackend) => void;
  onNavigateToStudio: () => void;
}

export const QuantumBackendsView: React.FC<QuantumBackendsViewProps> = ({
  activeBackend,
  onSelectBackend,
  onNavigateToStudio,
}) => {
  const [modalityFilter, setModalityFilter] = useState<string>('ALL');
  const [selectedNodeId, setSelectedNodeId] = useState<number>(0);
  const [imgFailed, setImgFailed] = useState<boolean>(false);

  const modalities = [
    'ALL',
    'Superconducting',
    'Trapped-Ion',
    'Neutral-Atom',
    'Tensor-GPU',
  ];

  const filteredBackends =
    modalityFilter === 'ALL'
      ? QUANTUM_BACKENDS
      : QUANTUM_BACKENDS.filter((b) => b.modality === modalityFilter);

  const inspectedNode =
    activeBackend.nodes.find((n) => n.id === selectedNodeId) ||
    activeBackend.nodes[0];

  const adjacentCouplers = activeBackend.couplers.filter(
    (c) => c.q1 === inspectedNode.id || c.q2 === inspectedNode.id
  );

  // Build 5-axis radar polygon coordinates
  const radarAxes = [
    { key: 'fidelity', label: '2Q FIDELITY', val: activeBackend.radarMetrics.fidelity },
    { key: 'coherence', label: 'T2 COHERENCE', val: activeBackend.radarMetrics.coherence },
    { key: 'connectivity', label: 'CONNECTIVITY', val: activeBackend.radarMetrics.connectivity },
    { key: 'speed', label: 'CLOPS SPEED', val: activeBackend.radarMetrics.speed },
    { key: 'scale', label: 'QUBIT SCALE', val: activeBackend.radarMetrics.scale },
  ];

  const radarCenter = 110;
  const radarRadius = 74;
  const polygonPoints = radarAxes
    .map((axis, idx) => {
      const angle = (2 * Math.PI * idx) / radarAxes.length - Math.PI / 2;
      const r = (axis.val / 100) * radarRadius;
      const x = radarCenter + r * Math.cos(angle);
      const y = radarCenter + r * Math.sin(angle);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  return (
    <div className="space-y-6">
      {/* Header & Modality Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#111827] border border-slate-800 p-5">
        <div>
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>QPU Fleet & Accelerated Simulators</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-emerald-400">
              ● 4 NOMINAL · 1 CALIBRATING
            </span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 mt-1">
            Quantum Processing Backends & Calibration Telemetry
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#07090E] border border-slate-800">
          {modalities.map((mod) => (
            <button
              key={mod}
              type="button"
              onClick={() => setModalityFilter(mod)}
              className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                modalityFilter === mod
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              {mod === 'ALL' ? 'All Modalities' : mod}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Grid: Fleet Table + Interactive Coupling Topology & Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Cols: High-Density Fleet Table & Hardware Cryostat Overview */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#111827] border border-slate-800 overflow-x-auto">
            <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-100">
                Available Quantum Processors & Tensor Simulators
              </h2>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                Click row to calibrate & target
              </span>
            </div>

            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-mono text-slate-400 bg-[#0B0E17]">
                  <th className="py-2.5 px-4">PROCESSOR</th>
                  <th className="py-2.5 px-3 text-right">QUBITS</th>
                  <th className="py-2.5 px-3 text-right">QV / CLOPS</th>
                  <th className="py-2.5 px-3 text-right">2Q ERROR</th>
                  <th className="py-2.5 px-3 text-right">MEDIAN T₂</th>
                  <th className="py-2.5 px-4 text-right">STATE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-xs">
                {filteredBackends.map((b) => {
                  const isSelected = b.id === activeBackend.id;
                  return (
                    <tr
                      key={b.id}
                      onClick={() => {
                        onSelectBackend(b);
                        setSelectedNodeId(0);
                      }}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-cyan-950/30 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100 flex items-center gap-2">
                          <span>{b.name}</span>
                          {isSelected && (
                            <span className="text-[11px] font-mono text-cyan-400">
                              [ACTIVE]
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          {b.modality} · {b.region}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-200">
                        {b.qubits} Q
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                        2^{Math.round(Math.log2(b.quantumVolume))} ·{' '}
                        {(b.clops / 1000).toFixed(1)}k
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-cyan-300">
                        {b.median2QError === 0
                          ? '0.000%'
                          : `${(b.median2QError * 100).toFixed(3)}%`}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                        {b.medianT2Us >= 99999
                          ? '∞ (Exact)'
                          : `${b.medianT2Us.toFixed(1)} μs`}
                      </td>
                      <td className="py-3 px-4 text-right font-mono whitespace-nowrap">
                        {b.status === 'NOMINAL' ? (
                          <span className="text-emerald-400">● NOMINAL</span>
                        ) : (
                          <span className="text-amber-400">▲ CALIBRATING</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Hardware Cryostat & Physical Architecture Spec Card */}
          <div className="bg-[#111827] border border-slate-800 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
            <div className="md:col-span-5 relative min-h-[210px] bg-[#07090E] border-b md:border-b-0 md:border-r border-slate-800">
              {!imgFailed ? (
                <img
                  src={cryostatImg}
                  alt="Dilution refrigerator quantum processor cryostat hardware"
                  referrerPolicy="no-referrer"
                  onError={() => setImgFailed(true)}
                  className="w-full h-full object-cover opacity-90"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-slate-900 to-slate-950">
                  <Cpu className="w-8 h-8 text-cyan-400 mb-2" />
                  <span className="text-xs font-mono text-slate-300">
                    Cryostat Stage Telemetry
                  </span>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-4">
                <div className="text-[11px] font-mono text-cyan-300">
                  {activeBackend.region}
                </div>
                <div className="text-sm font-semibold text-white">
                  {activeBackend.architecture}
                </div>
              </div>
            </div>

            <div className="md:col-span-7 p-5 flex flex-col justify-between space-y-4">
              <div>
                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <span>Selected Hardware Target</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-300">
                    Queue Depth: {activeBackend.queueDepth} jobs
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 mt-0.5">
                  {activeBackend.name} Specifications
                </h3>

                <div className="grid grid-cols-2 gap-y-3 gap-x-6 mt-4 text-xs">
                  <div>
                    <div className="text-slate-400">Mixing Chamber Temp</div>
                    <div className="font-mono text-sm font-semibold text-slate-100 tabular-nums mt-0.5">
                      {activeBackend.cryoTempMk !== null
                        ? `${activeBackend.cryoTempMk} mK`
                        : 'Room Temp / Optical Vacuum'}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400">1Q / 2Q Gate Duration</div>
                    <div className="font-mono text-sm font-semibold text-slate-100 tabular-nums mt-0.5">
                      {activeBackend.gateTime1QNs} ns / {activeBackend.gateTime2QNs} ns
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400">Median T₁ Relaxation</div>
                    <div className="font-mono text-sm font-semibold text-slate-100 tabular-nums mt-0.5">
                      {activeBackend.medianT1Us >= 99999
                        ? 'Ideal Statevector'
                        : `${activeBackend.medianT1Us} μs`}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400">Readout Assignment Error</div>
                    <div className="font-mono text-sm font-semibold text-cyan-400 tabular-nums mt-0.5">
                      {(activeBackend.medianReadoutError * 100).toFixed(2)} %
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                <div className="text-xs text-slate-400">
                  Recommended for:{' '}
                  <span className="text-slate-200 capitalize">
                    {activeBackend.recommendedFor.join(' · ')}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={onNavigateToStudio}
                  className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  Open in Circuit Studio
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Interactive Coupling Map & Radar Calibration Chart */}
        <div className="lg:col-span-5 space-y-6">
          {/* Interactive Qubit Coupling Graph */}
          <div className="bg-[#111827] border border-slate-800 p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Sub-Lattice Qubit Coupling & Coherence Map
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Click any physical qubit node in the {activeBackend.connectivity} to inspect calibration.
                </p>
              </div>
              <span className="text-xs font-mono text-cyan-400 tabular-nums">
                Node Q{inspectedNode.id}
              </span>
            </div>

            <div className="bg-[#07090E] border border-slate-800/90 p-3">
              <svg
                viewBox="0 0 480 280"
                className="w-full h-56 select-none cursor-crosshair"
              >
                {/* Coupler Edges */}
                {activeBackend.couplers.map((c, idx) => {
                  const n1 = activeBackend.nodes.find((n) => n.id === c.q1);
                  const n2 = activeBackend.nodes.find((n) => n.id === c.q2);
                  if (!n1 || !n2) return null;
                  const isConnectedToSelected =
                    c.q1 === inspectedNode.id || c.q2 === inspectedNode.id;
                  return (
                    <g key={idx}>
                      <line
                        x1={n1.x}
                        y1={n1.y}
                        x2={n2.x}
                        y2={n2.y}
                        stroke={isConnectedToSelected ? '#06B6D4' : '#334155'}
                        strokeWidth={isConnectedToSelected ? '2.5' : '1.5'}
                      />
                    </g>
                  );
                })}

                {/* Qubit Nodes */}
                {activeBackend.nodes.map((node) => {
                  const isSelected = node.id === inspectedNode.id;
                  return (
                    <g
                      key={node.id}
                      onClick={() => setSelectedNodeId(node.id)}
                      className="cursor-pointer"
                    >
                      {isSelected && (
                        <circle
                          cx={node.x}
                          cy={node.y}
                          r="21"
                          fill="none"
                          stroke="#06B6D4"
                          strokeWidth="1.2"
                          strokeDasharray="3 3"
                        />
                      )}
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r="15"
                        fill={isSelected ? '#06B6D4' : '#111827'}
                        stroke={isSelected ? '#67E8F9' : '#475569'}
                        strokeWidth="2"
                      />
                      <text
                        x={node.x}
                        y={node.y + 4}
                        textAnchor="middle"
                        className="font-mono text-[10px] font-bold"
                        fill={isSelected ? '#020617' : '#E2E8F0'}
                      >
                        Q{node.id}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Selected Node Readout */}
            <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-3 gap-3 font-mono text-xs tabular-nums">
              <div>
                <div className="text-slate-400 text-[11px]">Q{inspectedNode.id} FREQ / T₁</div>
                <div className="text-slate-100 font-semibold mt-0.5">
                  {inspectedNode.frequencyGhz} GHz · {inspectedNode.t1Us} μs
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-[11px]">1Q SX ERROR</div>
                <div className="text-cyan-400 font-semibold mt-0.5">
                  {(inspectedNode.singleQubitError * 100).toFixed(3)} %
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-[11px]">COUPLED LINKS</div>
                <div className="text-emerald-400 font-semibold mt-0.5">
                  {adjacentCouplers.length} links (
                  {adjacentCouplers[0]
                    ? `CZ ${(adjacentCouplers[0].czError * 100).toFixed(2)}%`
                    : 'Ideal'}
                  )
                </div>
              </div>
            </div>
          </div>

          {/* 5-Axis Spider / Radar Calibration Profile */}
          <div className="bg-[#111827] border border-slate-800 p-5">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-semibold text-slate-100">
                Multi-Axis Hardware Calibration Profile
              </h2>
              <span className="text-xs font-mono text-slate-400">
                Normalized 0–100 Scale
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              <svg viewBox="0 0 220 220" className="w-48 h-48 shrink-0">
                {/* Concentric Polygonal Rings */}
                {[0.25, 0.5, 0.75, 1.0].map((scale) => {
                  const ringPts = radarAxes
                    .map((_, idx) => {
                      const angle =
                        (2 * Math.PI * idx) / radarAxes.length - Math.PI / 2;
                      const r = scale * radarRadius;
                      const x = radarCenter + r * Math.cos(angle);
                      const y = radarCenter + r * Math.sin(angle);
                      return `${x.toFixed(1)},${y.toFixed(1)}`;
                    })
                    .join(' ');
                  return (
                    <polygon
                      key={scale}
                      points={ringPts}
                      fill="none"
                      stroke="#1E293B"
                      strokeWidth="1"
                    />
                  );
                })}

                {/* Radial Spokes & Labels */}
                {radarAxes.map((axis, idx) => {
                  const angle =
                    (2 * Math.PI * idx) / radarAxes.length - Math.PI / 2;
                  const xEnd = radarCenter + radarRadius * Math.cos(angle);
                  const yEnd = radarCenter + radarRadius * Math.sin(angle);
                  const xLbl =
                    radarCenter + (radarRadius + 21) * Math.cos(angle);
                  const yLbl =
                    radarCenter + (radarRadius + 16) * Math.sin(angle);

                  return (
                    <g key={axis.key}>
                      <line
                        x1={radarCenter}
                        y1={radarCenter}
                        x2={xEnd}
                        y2={yEnd}
                        stroke="#334155"
                        strokeWidth="1"
                      />
                      <text
                        x={xLbl}
                        y={yLbl}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="font-mono text-[8px] fill-slate-400"
                      >
                        {axis.label}
                      </text>
                    </g>
                  );
                })}

                {/* Active Backend Calibration Polygon */}
                <polygon
                  points={polygonPoints}
                  fill="rgba(6, 182, 212, 0.22)"
                  stroke="#06B6D4"
                  strokeWidth="2"
                />
              </svg>

              <div className="flex-1 w-full space-y-2 font-mono text-xs tabular-nums">
                {radarAxes.map((axis) => (
                  <div
                    key={axis.key}
                    className="flex items-center justify-between border-b border-slate-800/80 pb-1.5"
                  >
                    <span className="text-slate-400 text-[11px]">
                      {axis.label}
                    </span>
                    <span className="text-slate-100 font-semibold">
                      {axis.val} / 100
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
