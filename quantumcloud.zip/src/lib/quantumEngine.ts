export type GateType =
  | 'H'
  | 'X'
  | 'Y'
  | 'Z'
  | 'S'
  | 'T'
  | 'RX'
  | 'RY'
  | 'RZ'
  | 'CNOT'
  | 'CZ'
  | 'SWAP';

export type DomainCategory = 'research' | 'pharma' | 'finance';

export interface CircuitGate {
  id: string;
  type: GateType;
  qubit: number;
  targetQubit?: number; // For CNOT, CZ, SWAP
  step: number; // 0 to 11
  angle?: number; // In radians, for RX, RY, RZ
}

export interface Complex {
  re: number;
  im: number;
}

export interface BasisStateMeasurement {
  bitstring: string;
  index: number;
  amplitude: Complex;
  probability: number;
  phaseRad: number;
  idealShots: number;
  noisyShots: number;
}

export interface QubitBlochVector {
  qubit: number;
  x: number;
  y: number;
  z: number;
  purity: number; // 1.0 = pure unentangled state, 0.5 = maximally entangled
  p1: number; // Marginal probability of measuring |1>
}

export interface SimulationResult {
  numQubits: number;
  basisStates: BasisStateMeasurement[];
  blochVectors: QubitBlochVector[];
  circuitDepth: number;
  singleQubitGateCount: number;
  twoQubitGateCount: number;
  estimatedFidelity: number;
  estimatedDurationNs: number;
  entanglementEntropy: number;
}

export interface QpuCoupler {
  q1: number;
  q2: number;
  czError: number;
  gateTimeNs: number;
}

export interface QpuNode {
  id: number;
  x: number;
  y: number;
  t1Us: number;
  t2Us: number;
  readoutError: number;
  singleQubitError: number;
  frequencyGhz: number;
}

export interface QuantumBackend {
  id: string;
  name: string;
  modality: 'Superconducting' | 'Trapped-Ion' | 'Neutral-Atom' | 'Photonic' | 'Tensor-GPU';
  architecture: string;
  qubits: number;
  quantumVolume: number;
  clops: number; // Circuit Layer Operations Per Second
  medianT1Us: number;
  medianT2Us: number;
  median1QError: number;
  median2QError: number;
  medianReadoutError: number;
  gateTime1QNs: number;
  gateTime2QNs: number;
  connectivity: string;
  cryoTempMk: number | null;
  status: 'NOMINAL' | 'CALIBRATING' | 'DECOHERENCE_WARN';
  queueDepth: number;
  region: string;
  recommendedFor: DomainCategory[];
  nodes: QpuNode[];
  couplers: QpuCoupler[];
  radarMetrics: {
    fidelity: number;
    coherence: number;
    connectivity: number;
    speed: number;
    scale: number;
  };
}

export interface CircuitPreset {
  id: string;
  name: string;
  domain: DomainCategory;
  subtitle: string;
  description: string;
  numQubits: number;
  targetMetricLabel: string;
  targetMetricValue: string;
  referenceCitation: string;
  gates: CircuitGate[];
}

export interface HybridWorkflowPreset {
  id: string;
  name: string;
  domain: DomainCategory;
  algorithm: 'VQE' | 'QAOA' | 'QAE' | 'Trotter-Time-Evolution';
  targetSystem: string;
  hamiltonianTerms: number;
  ansatzName: string;
  exactReferenceValue: number;
  initialValue: number;
  unit: string;
  convergenceThreshold: number;
  thresholdLabel: string;
  description: string;
  pauliDecomposition: { term: string; coeff: number }[];
  clinicalOrFinancialImpact: string;
}

export interface CloudJobRecord {
  id: string;
  name: string;
  domain: DomainCategory;
  backendId: string;
  backendName: string;
  algorithm: string;
  qubits: number;
  depth: number;
  shots: number;
  status: 'COMPLETED' | 'RUNNING' | 'QUEUED';
  submittedAt: string;
  qpuRuntimeMs: number;
  fidelity: number;
  keyResult: string;
  presetId: string;
}

// Generate deterministic lattice nodes for backend visualization
function buildHeavyHexTopology(): { nodes: QpuNode[]; couplers: QpuCoupler[] } {
  const coords = [
    { x: 90, y: 60 }, { x: 190, y: 60 }, { x: 290, y: 60 }, { x: 390, y: 60 },
    { x: 90, y: 140 }, { x: 190, y: 140 }, { x: 290, y: 140 }, { x: 390, y: 140 },
    { x: 90, y: 220 }, { x: 190, y: 220 }, { x: 290, y: 220 }, { x: 390, y: 220 },
  ];
  const nodes: QpuNode[] = coords.map((pt, i) => ({
    id: i,
    x: pt.x,
    y: pt.y,
    t1Us: Number((285 + ((i * 37) % 95)).toFixed(1)),
    t2Us: Number((210 + ((i * 29) % 85)).toFixed(1)),
    readoutError: Number((0.0042 + ((i * 3) % 11) * 0.0004).toFixed(4)),
    singleQubitError: Number((0.00018 + ((i * 5) % 9) * 0.00003).toFixed(5)),
    frequencyGhz: Number((4.82 + ((i * 7) % 15) * 0.035).toFixed(3)),
  }));
  const edges = [
    [0, 1], [1, 2], [2, 3],
    [4, 5], [5, 6], [6, 7],
    [8, 9], [9, 10], [10, 11],
    [0, 4], [2, 6], [5, 9], [7, 11], [1, 5], [6, 10]
  ];
  const couplers: QpuCoupler[] = edges.map(([q1, q2], idx) => ({
    q1,
    q2,
    czError: Number((0.0019 + ((idx * 7) % 14) * 0.0002).toFixed(4)),
    gateTimeNs: 36 + ((idx * 5) % 12),
  }));
  return { nodes, couplers };
}

function buildAllToAllIonTopology(): { nodes: QpuNode[]; couplers: QpuCoupler[] } {
  const count = 10;
  const cx = 240;
  const cy = 140;
  const rx = 140;
  const ry = 92;
  const nodes: QpuNode[] = Array.from({ length: count }, (_, i) => {
    const angle = (2 * Math.PI * i) / count - Math.PI / 2;
    return {
      id: i,
      x: Math.round(cx + rx * Math.cos(angle)),
      y: Math.round(cy + ry * Math.sin(angle)),
      t1Us: Number((42000 + i * 1800).toFixed(0)),
      t2Us: Number((18500 + i * 950).toFixed(0)),
      readoutError: Number((0.0012 + (i % 4) * 0.0002).toFixed(4)),
      singleQubitError: Number((0.00007 + (i % 5) * 0.00001).toFixed(5)),
      frequencyGhz: Number((12.642 + i * 0.004).toFixed(3)),
    };
  });
  const couplers: QpuCoupler[] = [];
  for (let i = 0; i < count; i++) {
    for (let j = i + 1; j < count; j++) {
      if ((i + j) % 2 === 0 || j === i + 1 || (i === 0 && j === count - 1)) {
        couplers.push({
          q1: i,
          q2: j,
          czError: Number((0.0011 + ((i + j) % 6) * 0.00015).toFixed(4)),
          gateTimeNs: 210 + ((i * j) % 40),
        });
      }
    }
  }
  return { nodes, couplers };
}

function buildRydbergGridTopology(): { nodes: QpuNode[]; couplers: QpuCoupler[] } {
  const nodes: QpuNode[] = [];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 4; c++) {
      const i = r * 4 + c;
      const offset = r % 2 === 1 ? 25 : 0;
      nodes.push({
        id: i,
        x: 85 + c * 95 + offset,
        y: 55 + r * 85,
        t1Us: Number((4800 + i * 210).toFixed(0)),
        t2Us: Number((2600 + i * 140).toFixed(0)),
        readoutError: Number((0.0065 + (i % 5) * 0.0005).toFixed(4)),
        singleQubitError: Number((0.00045 + (i % 4) * 0.00005).toFixed(5)),
        frequencyGhz: Number((6.834 + i * 0.011).toFixed(3)),
      });
    }
  }
  const couplers: QpuCoupler[] = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist <= 125) {
        couplers.push({
          q1: i,
          q2: j,
          czError: Number((0.0038 + ((i + j) % 7) * 0.0003).toFixed(4)),
          gateTimeNs: 140 + ((i + j) % 25),
        });
      }
    }
  }
  return { nodes, couplers };
}

export const QUANTUM_BACKENDS: QuantumBackend[] = [
  {
    id: 'kronos-156-sc',
    name: 'Kronos-156 Heron',
    modality: 'Superconducting',
    architecture: 'Tunable-Coupler Heavy-Hex Lattice',
    qubits: 156,
    quantumVolume: 32768,
    clops: 195000,
    medianT1Us: 342.8,
    medianT2Us: 268.4,
    median1QError: 0.00019,
    median2QError: 0.00185,
    medianReadoutError: 0.0046,
    gateTime1QNs: 24,
    gateTime2QNs: 38,
    connectivity: 'Degree-3 Heavy-Hex Lattice',
    cryoTempMk: 12.4,
    status: 'NOMINAL',
    queueDepth: 4,
    region: 'Zurich Cryo-Facility A',
    recommendedFor: ['pharma', 'finance', 'research'],
    ...buildHeavyHexTopology(),
    radarMetrics: {
      fidelity: 94,
      coherence: 82,
      connectivity: 74,
      speed: 98,
      scale: 92,
    },
  },
  {
    id: 'helion-64-ion',
    name: 'Helion-64 Barium',
    modality: 'Trapped-Ion',
    architecture: '133Ba+ Linear Paul RF Trap',
    qubits: 64,
    quantumVolume: 2097152,
    clops: 4800,
    medianT1Us: 48500.0,
    medianT2Us: 21400.0,
    median1QError: 0.00008,
    median2QError: 0.00115,
    medianReadoutError: 0.0013,
    gateTime1QNs: 180,
    gateTime2QNs: 230,
    connectivity: 'All-to-All Acoustic Mode Bus',
    cryoTempMk: 4200,
    status: 'NOMINAL',
    queueDepth: 7,
    region: 'Boulder Optical Vault',
    recommendedFor: ['pharma', 'finance'],
    ...buildAllToAllIonTopology(),
    radarMetrics: {
      fidelity: 99,
      coherence: 99,
      connectivity: 100,
      speed: 62,
      scale: 72,
    },
  },
  {
    id: 'hyperion-256-na',
    name: 'Hyperion-256 Rubidium',
    modality: 'Neutral-Atom',
    architecture: '87Rb Optical Tweezer Rydberg Array',
    qubits: 256,
    quantumVolume: 16384,
    clops: 14200,
    medianT1Us: 5400.0,
    medianT2Us: 2950.0,
    median1QError: 0.00048,
    median2QError: 0.0041,
    medianReadoutError: 0.0072,
    gateTime1QNs: 95,
    gateTime2QNs: 155,
    connectivity: 'Reconfigurable Rydberg Blockade Zone',
    cryoTempMk: null,
    status: 'NOMINAL',
    queueDepth: 2,
    region: 'Munich Quantum Hub',
    recommendedFor: ['research', 'finance'],
    ...buildRydbergGridTopology(),
    radarMetrics: {
      fidelity: 87,
      coherence: 91,
      connectivity: 89,
      speed: 75,
      scale: 98,
    },
  },
  {
    id: 'cuquantum-tensor-sim',
    name: 'Aether-MPS Tensor Simulator',
    modality: 'Tensor-GPU',
    architecture: '8x H200 GPU Matrix Product State Cluster',
    qubits: 64,
    quantumVolume: 4194304,
    clops: 840000,
    medianT1Us: 999999,
    medianT2Us: 999999,
    median1QError: 0.0,
    median2QError: 0.0,
    medianReadoutError: 0.0,
    gateTime1QNs: 1,
    gateTime2QNs: 2,
    connectivity: 'Full All-to-All Exact Statevector / MPS',
    cryoTempMk: null,
    status: 'NOMINAL',
    queueDepth: 0,
    region: 'US-East Accelerated Compute',
    recommendedFor: ['research', 'pharma', 'finance'],
    ...buildAllToAllIonTopology(),
    radarMetrics: {
      fidelity: 100,
      coherence: 100,
      connectivity: 100,
      speed: 100,
      scale: 78,
    },
  },
  {
    id: 'nyx-84-sc',
    name: 'Nyx-84 Fluxonium',
    modality: 'Superconducting',
    architecture: 'High-Anharmonicity Fluxonium Planar Grid',
    qubits: 84,
    quantumVolume: 65536,
    clops: 162000,
    medianT1Us: 890.5,
    medianT2Us: 640.2,
    median1QError: 0.00014,
    median2QError: 0.00142,
    medianReadoutError: 0.0038,
    gateTime1QNs: 20,
    gateTime2QNs: 32,
    connectivity: 'Degree-4 Square Lattice',
    cryoTempMk: 10.8,
    status: 'CALIBRATING',
    queueDepth: 11,
    region: 'Tokyo Cryogenic Lab',
    recommendedFor: ['pharma', 'research'],
    ...buildHeavyHexTopology(),
    radarMetrics: {
      fidelity: 96,
      coherence: 89,
      connectivity: 82,
      speed: 96,
      scale: 84,
    },
  },
];

export const CIRCUIT_PRESETS: CircuitPreset[] = [
  {
    id: 'pharma-lih-vqe',
    name: 'LiH Ground-State UCCSD Ansatz',
    domain: 'pharma',
    subtitle: 'Active-Space Molecular Electronic Structure (4 Qubits)',
    description:
      'Unitary Coupled-Cluster Singles and Doubles (UCCSD) variational circuit under Jordan-Wigner mapping at bond length R = 1.595 Å.',
    numQubits: 4,
    targetMetricLabel: 'Ground State Energy',
    targetMetricValue: '-7.8823 Ha',
    referenceCitation: 'J. Chem. Theory Comput. · 1.6 mHa Chemical Accuracy',
    gates: [
      { id: 'g1', type: 'X', qubit: 0, step: 0 },
      { id: 'g2', type: 'X', qubit: 1, step: 0 },
      { id: 'g3', type: 'RY', qubit: 0, step: 1, angle: 0.42 },
      { id: 'g4', type: 'RY', qubit: 2, step: 1, angle: -0.38 },
      { id: 'g5', type: 'CNOT', qubit: 0, targetQubit: 1, step: 2 },
      { id: 'g6', type: 'CNOT', qubit: 1, targetQubit: 2, step: 3 },
      { id: 'g7', type: 'RZ', qubit: 2, step: 4, angle: -0.64 },
      { id: 'g8', type: 'CNOT', qubit: 2, targetQubit: 3, step: 5 },
      { id: 'g9', type: 'RY', qubit: 3, step: 6, angle: 0.51 },
      { id: 'g10', type: 'CNOT', qubit: 1, targetQubit: 2, step: 7 },
      { id: 'g11', type: 'RZ', qubit: 0, step: 8, angle: 0.29 },
    ],
  },
  {
    id: 'pharma-kras-pocket',
    name: 'KRAS G12C Covalent Pocket VQE',
    domain: 'pharma',
    subtitle: 'Oncology Ligand-Residue Electrostatic Embedding (5 Qubits)',
    description:
      'Hardware-efficient symmetry-preserving ansatz modeling Cys12 thiol nucleophilic warhead polarization in KRAS G12C inhibitor docking.',
    numQubits: 5,
    targetMetricLabel: 'Binding ΔG Estimate',
    targetMetricValue: '-11.42 kcal/mol',
    referenceCitation: 'DMET Fragment Embedding · 5-Orbital Active Space',
    gates: [
      { id: 'k1', type: 'X', qubit: 0, step: 0 },
      { id: 'k2', type: 'X', qubit: 2, step: 0 },
      { id: 'k3', type: 'H', qubit: 1, step: 1 },
      { id: 'k4', type: 'RY', qubit: 3, step: 1, angle: 0.78 },
      { id: 'k5', type: 'CNOT', qubit: 0, targetQubit: 1, step: 2 },
      { id: 'k6', type: 'CNOT', qubit: 2, targetQubit: 3, step: 2 },
      { id: 'k7', type: 'RZ', qubit: 1, step: 3, angle: -0.92 },
      { id: 'k8', type: 'CNOT', qubit: 3, targetQubit: 4, step: 4 },
      { id: 'k9', type: 'RY', qubit: 4, step: 5, angle: 0.63 },
      { id: 'k10', type: 'CZ', qubit: 1, targetQubit: 2, step: 6 },
      { id: 'k11', type: 'RX', qubit: 0, step: 7, angle: -0.45 },
    ],
  },
  {
    id: 'finance-cvar-qae',
    name: 'Credit Portfolio Tail-Risk QAE',
    domain: 'finance',
    subtitle: 'Iterative Quantum Amplitude Estimation for 99.5% CVaR (5 Qubits)',
    description:
      'Loads correlated sovereign credit loss distribution into quantum registers and applies Grover-like amplitude amplification to estimate tail Conditional Value-at-Risk.',
    numQubits: 5,
    targetMetricLabel: '99.5% Tail CVaR',
    targetMetricValue: '$14.82M · O(1/ε) Speedup',
    referenceCitation: 'Iterative QAE · Quadratic Query Reduction vs Monte Carlo',
    gates: [
      { id: 'f1', type: 'RY', qubit: 0, step: 0, angle: 1.12 },
      { id: 'f2', type: 'RY', qubit: 1, step: 0, angle: 0.84 },
      { id: 'f3', type: 'RY', qubit: 2, step: 0, angle: 0.56 },
      { id: 'f4', type: 'RY', qubit: 3, step: 0, angle: 0.34 },
      { id: 'f5', type: 'CNOT', qubit: 0, targetQubit: 4, step: 1 },
      { id: 'f6', type: 'CNOT', qubit: 1, targetQubit: 4, step: 2 },
      { id: 'f7', type: 'RY', qubit: 4, step: 3, angle: 0.96 },
      { id: 'f8', type: 'CZ', qubit: 2, targetQubit: 4, step: 4 },
      { id: 'f9', type: 'H', qubit: 0, step: 5 },
      { id: 'f10', type: 'H', qubit: 1, step: 5 },
      { id: 'f11', type: 'CNOT', qubit: 3, targetQubit: 4, step: 6 },
    ],
  },
  {
    id: 'finance-qaoa-portfolio',
    name: 'Multi-Asset Sharpe Ratio QAOA',
    domain: 'finance',
    subtitle: 'Discrete Markowitz Covariance Combinatorial Mixer (4 Qubits)',
    description:
      'Alternating Cost-Hamiltonian ZZ phase separators and transverse-field X-mixers solving constrained asset allocation under transaction cost penalties.',
    numQubits: 4,
    targetMetricLabel: 'Expected Sharpe Ratio',
    targetMetricValue: '2.84 · Approximation Ratio 0.964',
    referenceCitation: 'QAOA p=2 Depth · Covariance Ising Mapping',
    gates: [
      { id: 'q1', type: 'H', qubit: 0, step: 0 },
      { id: 'q2', type: 'H', qubit: 1, step: 0 },
      { id: 'q3', type: 'H', qubit: 2, step: 0 },
      { id: 'q4', type: 'H', qubit: 3, step: 0 },
      { id: 'q5', type: 'CNOT', qubit: 0, targetQubit: 1, step: 1 },
      { id: 'q6', type: 'CNOT', qubit: 2, targetQubit: 3, step: 1 },
      { id: 'q7', type: 'RZ', qubit: 1, step: 2, angle: 0.72 },
      { id: 'q8', type: 'RZ', qubit: 3, step: 2, angle: -0.58 },
      { id: 'q9', type: 'CNOT', qubit: 0, targetQubit: 1, step: 3 },
      { id: 'q10', type: 'CNOT', qubit: 2, targetQubit: 3, step: 3 },
      { id: 'q11', type: 'RX', qubit: 0, step: 4, angle: 0.88 },
      { id: 'q12', type: 'RX', qubit: 1, step: 4, angle: 0.88 },
      { id: 'q13', type: 'RX', qubit: 2, step: 4, angle: 0.88 },
      { id: 'q14', type: 'RX', qubit: 3, step: 4, angle: 0.88 },
    ],
  },
  {
    id: 'research-ghz-cat',
    name: '5-Qubit GHZ Maximally Entangled Cat State',
    domain: 'research',
    subtitle: 'Non-Local Multipartite Bell Inequality Benchmark (5 Qubits)',
    description:
      'Constructs the canonical (|00000⟩ + e^{iφ}|11111⟩)/√2 state for Mermin-inequality violation and macroscopic decoherence benchmarking.',
    numQubits: 5,
    targetMetricLabel: 'Multipartite Parity Fidelity',
    targetMetricValue: '98.42% · S = 3.89 Bell Witness',
    referenceCitation: 'Phys. Rev. Lett. · Parity Oscillation Protocol',
    gates: [
      { id: 'r1', type: 'H', qubit: 0, step: 0 },
      { id: 'r2', type: 'CNOT', qubit: 0, targetQubit: 1, step: 1 },
      { id: 'r3', type: 'CNOT', qubit: 1, targetQubit: 2, step: 2 },
      { id: 'r4', type: 'CNOT', qubit: 2, targetQubit: 3, step: 3 },
      { id: 'r5', type: 'CNOT', qubit: 3, targetQubit: 4, step: 4 },
      { id: 'r6', type: 'RZ', qubit: 4, step: 5, angle: 0.52 },
    ],
  },
  {
    id: 'research-ising-trotter',
    name: 'Transverse-Field Ising Floquet Dynamics',
    domain: 'research',
    subtitle: 'First-Order Suzuki-Trotter Spin Chain Evolution (4 Qubits)',
    description:
      'Simulates out-of-equilibrium magnetization quench dynamics under nearest-neighbor ZZ coupling and transverse magnetic field.',
    numQubits: 4,
    targetMetricLabel: 'Staggered Magnetization ⟨Mz⟩',
    targetMetricValue: '+0.614 ℏ · Δt = 0.45 ps',
    referenceCitation: 'Suzuki-Trotter Decomposition · 2-Step Quench',
    gates: [
      { id: 't1', type: 'RX', qubit: 0, step: 0, angle: 0.65 },
      { id: 't2', type: 'RX', qubit: 1, step: 0, angle: 0.65 },
      { id: 't3', type: 'RX', qubit: 2, step: 0, angle: 0.65 },
      { id: 't4', type: 'RX', qubit: 3, step: 0, angle: 0.65 },
      { id: 't5', type: 'CZ', qubit: 0, targetQubit: 1, step: 1 },
      { id: 't6', type: 'CZ', qubit: 2, targetQubit: 3, step: 1 },
      { id: 't7', type: 'CZ', qubit: 1, targetQubit: 2, step: 2 },
      { id: 't8', type: 'RZ', qubit: 1, step: 3, angle: -0.78 },
      { id: 't9', type: 'RZ', qubit: 2, step: 3, angle: 0.78 },
      { id: 't10', type: 'H', qubit: 0, step: 4 },
      { id: 't11', type: 'H', qubit: 3, step: 4 },
    ],
  },
];

export const HYBRID_WORKFLOW_PRESETS: HybridWorkflowPreset[] = [
  {
    id: 'wf-pharma-kras',
    name: 'KRAS G12C Covalent Inhibitor Pocket VQE',
    domain: 'pharma',
    algorithm: 'VQE',
    targetSystem: 'Sotorasib-Analogue / Cys12 Active Site (12 Spin-Orbitals)',
    hamiltonianTerms: 642,
    ansatzName: 'k-UpCCGSD Symmetry-Adapted',
    exactReferenceValue: -542.8942,
    initialValue: -541.9210,
    unit: 'Ha',
    convergenceThreshold: 0.0016,
    thresholdLabel: 'Chemical Accuracy (1.6 mHa)',
    description:
      'Hybrid Density Matrix Embedding Theory (DMET) + Variational Quantum Eigensolver computing the transition-state activation barrier for acrylamide warhead covalent bond formation.',
    pauliDecomposition: [
      { term: 'I ⊗ I ⊗ Z ⊗ Z ⊗ I', coeff: -0.48291 },
      { term: 'Z ⊗ Z ⊗ I ⊗ I ⊗ Z', coeff: +0.21904 },
      { term: 'X ⊗ X ⊗ Y ⊗ Y ⊗ I', coeff: -0.08412 },
      { term: 'Y ⊗ X ⊗ X ⊗ Y ⊗ I', coeff: +0.08412 },
      { term: 'Z ⊗ I ⊗ Z ⊗ I ⊗ Z', coeff: -0.14982 },
      { term: 'X ⊗ Z ⊗ X ⊗ I ⊗ I', coeff: +0.04195 },
    ],
    clinicalOrFinancialImpact:
      'Reduces lead-optimization binding free energy rank-ordering error from 2.1 kcal/mol (DFT B3LYP) to 0.34 kcal/mol across 48 candidate warheads.',
  },
  {
    id: 'wf-finance-cvar',
    name: 'Sovereign Fixed-Income Tail CVaR Estimation',
    domain: 'finance',
    algorithm: 'QAE',
    targetSystem: '120-Tranche Multi-Currency Credit Basket (99.5% Confidence)',
    hamiltonianTerms: 256,
    ansatzName: 'Iterative Grover-Free Amplitude Estimation',
    exactReferenceValue: 14.824,
    initialValue: 18.950,
    unit: 'USD Millions',
    convergenceThreshold: 0.045,
    thresholdLabel: 'Basel IV Regulatory Tolerance (±45k USD)',
    description:
      'Replaces 10^7 classical Monte Carlo paths with coherent Gaussian copula state preparation and iterative phase-kickback circuits to price extreme tail credit default cascades.',
    pauliDecomposition: [
      { term: 'Z ⊗ I ⊗ I ⊗ Z ⊗ I', coeff: +0.61240 },
      { term: 'I ⊗ Z ⊗ Z ⊗ I ⊗ Z', coeff: -0.34118 },
      { term: 'X ⊗ I ⊗ X ⊗ Z ⊗ I', coeff: +0.12890 },
      { term: 'Z ⊗ Z ⊗ Z ⊗ I ⊗ I', coeff: -0.09450 },
      { term: 'I ⊗ Y ⊗ Y ⊗ I ⊗ Z', coeff: +0.05812 },
    ],
    clinicalOrFinancialImpact:
      'Achieves 18.4x wall-clock latency compression for intraday VaR/CVaR desk rebalancing during high-volatility macro correlation shocks.',
  },
  {
    id: 'wf-research-hubbard',
    name: '2D Fermi-Hubbard Cuprate Superconductor Plaquette',
    domain: 'research',
    algorithm: 'Trotter-Time-Evolution',
    targetSystem: '2×4 Strongly Correlated Lattice (U/t = 8.0, Hole-Doped)',
    hamiltonianTerms: 512,
    ansatzName: 'Hamiltonian Variational Ansatz (HVA)',
    exactReferenceValue: -6.4182,
    initialValue: -5.3100,
    unit: 't (Hopping Energy)',
    convergenceThreshold: 0.008,
    thresholdLabel: 'd-Wave Pairing Gap Resolution (0.008 t)',
    description:
      'Resolves competing stripe-order antiferromagnetism and d-wave superconducting pairing correlations in doped Hubbard models beyond classical sign-problem limits.',
    pauliDecomposition: [
      { term: 'X ⊗ Z ⊗ X ⊗ I ⊗ I', coeff: -0.50000 },
      { term: 'Y ⊗ Z ⊗ Y ⊗ I ⊗ I', coeff: -0.50000 },
      { term: 'Z ⊗ I ⊗ I ⊗ Z ⊗ I', coeff: +2.00000 },
      { term: 'I ⊗ X ⊗ Z ⊗ X ⊗ I', coeff: -0.50000 },
      { term: 'I ⊗ Z ⊗ I ⊗ I ⊗ Z', coeff: +2.00000 },
    ],
    clinicalOrFinancialImpact:
      'Identifies optimal inter-layer hopping parameters for high-Tc superconducting material synthesis without Fermionic Monte Carlo sign breakdown.',
  },
];

export const INITIAL_CLOUD_JOBS: CloudJobRecord[] = [
  {
    id: 'job-9482-kras',
    name: 'KRAS-G12C-Cys12-UCCSD-Batch-04',
    domain: 'pharma',
    backendId: 'helion-64-ion',
    backendName: 'Helion-64 Barium',
    algorithm: 'ADAPT-VQE + ZNE',
    qubits: 5,
    depth: 18,
    shots: 8192,
    status: 'COMPLETED',
    submittedAt: '14m ago',
    qpuRuntimeMs: 1840,
    fidelity: 0.986,
    keyResult: '-542.8931 Ha (ΔE = 1.1 mHa)',
    presetId: 'pharma-kras-pocket',
  },
  {
    id: 'job-9481-cvar',
    name: 'EMEA-Sovereign-CVaR-995-QAE',
    domain: 'finance',
    backendId: 'kronos-156-sc',
    backendName: 'Kronos-156 Heron',
    algorithm: 'Iterative QAE',
    qubits: 5,
    depth: 14,
    shots: 4096,
    status: 'COMPLETED',
    submittedAt: '29m ago',
    qpuRuntimeMs: 412,
    fidelity: 0.964,
    keyResult: 'CVaR = $14.84M (±0.31%)',
    presetId: 'finance-cvar-qae',
  },
  {
    id: 'job-9480-lih',
    name: 'LiH-Bond-Dissociation-Scan-1.6A',
    domain: 'pharma',
    backendId: 'kronos-156-sc',
    backendName: 'Kronos-156 Heron',
    algorithm: 'UCCSD VQE',
    qubits: 4,
    depth: 11,
    shots: 4096,
    status: 'COMPLETED',
    submittedAt: '1h ago',
    qpuRuntimeMs: 325,
    fidelity: 0.978,
    keyResult: '-7.8819 Ha (Converged)',
    presetId: 'pharma-lih-vqe',
  },
  {
    id: 'job-9479-ghz',
    name: 'Multipartite-Bell-Mermin-5Q',
    domain: 'research',
    backendId: 'hyperion-256-na',
    backendName: 'Hyperion-256 Rubidium',
    algorithm: 'Parity Tomography',
    qubits: 5,
    depth: 8,
    shots: 8192,
    status: 'COMPLETED',
    submittedAt: '2h ago',
    qpuRuntimeMs: 690,
    fidelity: 0.971,
    keyResult: 'S = 3.884 ± 0.019',
    presetId: 'research-ghz-cat',
  },
  {
    id: 'job-9478-qaoa',
    name: 'FX-Basket-Markowitz-QAOA-p2',
    domain: 'finance',
    backendId: 'cuquantum-tensor-sim',
    backendName: 'Aether-MPS Tensor Simulator',
    algorithm: 'QAOA Mixer p=2',
    qubits: 4,
    depth: 12,
    shots: 8192,
    status: 'COMPLETED',
    submittedAt: '3h ago',
    qpuRuntimeMs: 48,
    fidelity: 1.0,
    keyResult: 'Sharpe = 2.84 (Ratio 0.964)',
    presetId: 'finance-qaoa-portfolio',
  },
];

// Complex arithmetic helpers
function cAdd(a: Complex, b: Complex): Complex {
  return { re: a.re + b.re, im: a.im + b.im };
}

function cMul(a: Complex, b: Complex): Complex {
  return {
    re: a.re * b.re - a.im * b.im,
    im: a.re * b.im + a.im * b.re,
  };
}

function cAbsSq(a: Complex): number {
  return a.re * a.re + a.im * a.im;
}

/**
 * Applies a 2x2 single-qubit unitary matrix [[u00, u01], [u10, u11]] to target qubit `q`
 */
function applySingleQubitUnitary(
  state: Complex[],
  numQubits: number,
  q: number,
  u00: Complex,
  u01: Complex,
  u10: Complex,
  u11: Complex
): void {
  const dim = 1 << numQubits;
  const bitMask = 1 << (numQubits - 1 - q);
  for (let i = 0; i < dim; i++) {
    if ((i & bitMask) === 0) {
      const j = i | bitMask;
      const s0 = state[i];
      const s1 = state[j];
      state[i] = cAdd(cMul(u00, s0), cMul(u01, s1));
      state[j] = cAdd(cMul(u10, s0), cMul(u11, s1));
    }
  }
}

/**
 * Executes a full quantum circuit on an N-qubit statevector and computes
 * probabilities, phases, Bloch vectors, entanglement entropy, and hardware noise shots.
 */
export function simulateQuantumCircuit(
  numQubits: number,
  gates: CircuitGate[],
  shots: number,
  backend: QuantumBackend,
  useNoiseModel: boolean
): SimulationResult {
  const dim = 1 << numQubits;
  const state: Complex[] = Array.from({ length: dim }, (_, idx) => ({
    re: idx === 0 ? 1.0 : 0.0,
    im: 0.0,
  }));

  // Sort gates by step ascending
  const activeGates = gates
    .filter(
      (g) =>
        g.qubit < numQubits &&
        (g.targetQubit === undefined || g.targetQubit < numQubits)
    )
    .sort((a, b) => a.step - b.step);

  const invSqrt2 = 1 / Math.sqrt(2);
  let singleQubitGateCount = 0;
  let twoQubitGateCount = 0;
  const occupiedSteps = new Set<number>();

  for (const gate of activeGates) {
    occupiedSteps.add(gate.step);
    const q = gate.qubit;
    const theta = gate.angle ?? Math.PI / 4;

    switch (gate.type) {
      case 'H':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: invSqrt2, im: 0 },
          { re: invSqrt2, im: 0 },
          { re: invSqrt2, im: 0 },
          { re: -invSqrt2, im: 0 }
        );
        break;
      case 'X':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: 0, im: 0 },
          { re: 1, im: 0 },
          { re: 1, im: 0 },
          { re: 0, im: 0 }
        );
        break;
      case 'Y':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: 0, im: 0 },
          { re: 0, im: -1 },
          { re: 0, im: 1 },
          { re: 0, im: 0 }
        );
        break;
      case 'Z':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: 1, im: 0 },
          { re: 0, im: 0 },
          { re: 0, im: 0 },
          { re: -1, im: 0 }
        );
        break;
      case 'S':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: 1, im: 0 },
          { re: 0, im: 0 },
          { re: 0, im: 0 },
          { re: 0, im: 1 }
        );
        break;
      case 'T':
        singleQubitGateCount++;
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: 1, im: 0 },
          { re: 0, im: 0 },
          { re: 0, im: 0 },
          { re: invSqrt2, im: invSqrt2 }
        );
        break;
      case 'RX': {
        singleQubitGateCount++;
        const c = Math.cos(theta / 2);
        const s = Math.sin(theta / 2);
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: c, im: 0 },
          { re: 0, im: -s },
          { re: 0, im: -s },
          { re: c, im: 0 }
        );
        break;
      }
      case 'RY': {
        singleQubitGateCount++;
        const c = Math.cos(theta / 2);
        const s = Math.sin(theta / 2);
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: c, im: 0 },
          { re: -s, im: 0 },
          { re: s, im: 0 },
          { re: c, im: 0 }
        );
        break;
      }
      case 'RZ': {
        singleQubitGateCount++;
        const c = Math.cos(theta / 2);
        const s = Math.sin(theta / 2);
        applySingleQubitUnitary(
          state,
          numQubits,
          q,
          { re: c, im: -s },
          { re: 0, im: 0 },
          { re: 0, im: 0 },
          { re: c, im: s }
        );
        break;
      }
      case 'CNOT': {
        twoQubitGateCount++;
        const target = gate.targetQubit ?? (q + 1) % numQubits;
        const cMask = 1 << (numQubits - 1 - q);
        const tMask = 1 << (numQubits - 1 - target);
        for (let i = 0; i < dim; i++) {
          if ((i & cMask) !== 0 && (i & tMask) === 0) {
            const j = i | tMask;
            const tmp = state[i];
            state[i] = state[j];
            state[j] = tmp;
          }
        }
        break;
      }
      case 'CZ': {
        twoQubitGateCount++;
        const target = gate.targetQubit ?? (q + 1) % numQubits;
        const cMask = 1 << (numQubits - 1 - q);
        const tMask = 1 << (numQubits - 1 - target);
        for (let i = 0; i < dim; i++) {
          if ((i & cMask) !== 0 && (i & tMask) !== 0) {
            state[i] = { re: -state[i].re, im: -state[i].im };
          }
        }
        break;
      }
      case 'SWAP': {
        twoQubitGateCount++;
        const target = gate.targetQubit ?? (q + 1) % numQubits;
        const m1 = 1 << (numQubits - 1 - q);
        const m2 = 1 << (numQubits - 1 - target);
        for (let i = 0; i < dim; i++) {
          const b1 = (i & m1) !== 0 ? 1 : 0;
          const b2 = (i & m2) !== 0 ? 1 : 0;
          if (b1 === 0 && b2 === 1) {
            const j = (i | m1) & ~m2;
            const tmp = state[i];
            state[i] = state[j];
            state[j] = tmp;
          }
        }
        break;
      }
    }
  }

  const circuitDepth = occupiedSteps.size;
  const estimatedDurationNs =
    circuitDepth * Math.max(backend.gateTime1QNs, backend.gateTime2QNs * 0.85);

  // Compute hardware gate + decoherence fidelity
  const gateSurvival =
    Math.pow(1 - backend.median1QError, singleQubitGateCount) *
    Math.pow(1 - backend.median2QError, twoQubitGateCount) *
    Math.pow(1 - backend.medianReadoutError, numQubits);
  const decoherenceFactor = Math.exp(
    -estimatedDurationNs / (backend.medianT2Us * 1000)
  );
  const estimatedFidelity = Number(
    Math.max(0.1, Math.min(1.0, gateSurvival * decoherenceFactor)).toFixed(4)
  );

  // Uniform depolarizing floor when noise model is enabled
  const uniformProb = 1 / dim;
  const depolarizingStrength = useNoiseModel ? 1 - estimatedFidelity : 0;

  const basisStates: BasisStateMeasurement[] = state.map((amp, idx) => {
    const bitstring = idx.toString(2).padStart(numQubits, '0');
    const prob = cAbsSq(amp);
    const phaseRad =
      prob > 1e-9 ? Math.atan2(amp.im, amp.re) : 0;

    const noisyProb =
      (1 - depolarizingStrength) * prob + depolarizingStrength * uniformProb;

    // Deterministic pseudo-shot fluctuation around expected multinomial count
    const pseudoJitter =
      Math.sin(idx * 12.9898 + activeGates.length * 78.233) *
      Math.sqrt(shots * noisyProb * (1 - noisyProb)) *
      0.35;

    const idealShots = Math.round(prob * shots);
    const noisyShots = useNoiseModel
      ? Math.max(0, Math.round(noisyProb * shots + pseudoJitter))
      : idealShots;

    return {
      bitstring,
      index: idx,
      amplitude: amp,
      probability: prob,
      phaseRad,
      idealShots,
      noisyShots,
    };
  });

  // Compute reduced single-qubit density matrix and Bloch vectors
  const blochVectors: QubitBlochVector[] = [];
  for (let q = 0; q < numQubits; q++) {
    const mask = 1 << (numQubits - 1 - q);
    let rho00 = 0;
    let rho11 = 0;
    let rho01Re = 0;
    let rho01Im = 0;

    for (let i = 0; i < dim; i++) {
      if ((i & mask) === 0) {
        const j = i | mask;
        const a0 = state[i];
        const a1 = state[j];
        rho00 += cAbsSq(a0);
        rho11 += cAbsSq(a1);
        // a0 * conj(a1)
        rho01Re += a0.re * a1.re + a0.im * a1.im;
        rho01Im += a0.im * a1.re - a0.re * a1.im;
      }
    }

    const x = 2 * rho01Re;
    const y = -2 * rho01Im;
    const z = rho00 - rho11;
    const purity = Math.min(
      1.0,
      rho00 * rho00 + rho11 * rho11 + 2 * (rho01Re * rho01Re + rho01Im * rho01Im)
    );

    blochVectors.push({
      qubit: q,
      x: Number(x.toFixed(3)),
      y: Number(y.toFixed(3)),
      z: Number(z.toFixed(3)),
      purity: Number(purity.toFixed(3)),
      p1: Number(rho11.toFixed(4)),
    });
  }

  // Average bipartite Von Neumann entanglement indicator from single-qubit purities
  const avgMixedness =
    blochVectors.reduce((acc, b) => acc + (1 - b.purity), 0) / numQubits;
  const entanglementEntropy = Number((avgMixedness * 2).toFixed(3));

  return {
    numQubits,
    basisStates,
    blochVectors,
    circuitDepth,
    singleQubitGateCount,
    twoQubitGateCount,
    estimatedFidelity,
    estimatedDurationNs: Math.round(estimatedDurationNs),
    entanglementEntropy,
  };
}

/**
 * Generates OpenQASM 3.0 source code from the active circuit
 */
export function generateOpenQasm3(
  numQubits: number,
  gates: CircuitGate[],
  backend: QuantumBackend,
  optLevel: 0 | 1 | 2 | 3
): string {
  const sorted = [...gates]
    .filter((g) => g.qubit < numQubits && (g.targetQubit === undefined || g.targetQubit < numQubits))
    .sort((a, b) => a.step - b.step);

  const lines: string[] = [
    'OPENQASM 3.0;',
    'include "stdgates.inc";',
    '',
    `// Target QPU: ${backend.name} (${backend.architecture})`,
    `// Transpiler Optimization Level: O${optLevel}`,
    `qubit[${numQubits}] q;`,
    `bit[${numQubits}] c;`,
    '',
  ];

  for (const g of sorted) {
    const thetaStr = g.angle !== undefined ? g.angle.toFixed(4) : '0.7854';
    switch (g.type) {
      case 'H':
      case 'X':
      case 'Y':
      case 'Z':
      case 'S':
      case 'T':
        lines.push(`${g.type.toLowerCase()} q[${g.qubit}];`);
        break;
      case 'RX':
      case 'RY':
      case 'RZ':
        lines.push(`${g.type.toLowerCase()}(${thetaStr}) q[${g.qubit}];`);
        break;
      case 'CNOT':
        lines.push(`cx q[${g.qubit}], q[${g.targetQubit ?? (g.qubit + 1) % numQubits}];`);
        break;
      case 'CZ':
        lines.push(`cz q[${g.qubit}], q[${g.targetQubit ?? (g.qubit + 1) % numQubits}];`);
        break;
      case 'SWAP':
        lines.push(`swap q[${g.qubit}], q[${g.targetQubit ?? (g.qubit + 1) % numQubits}];`);
        break;
    }
  }

  lines.push('');
  lines.push('c = measure q;');
  return lines.join('\n');
}

/**
 * Generates Veritas Python SDK / Qiskit-compatible script from the active circuit
 */
export function generatePythonSdkCode(
  numQubits: number,
  gates: CircuitGate[],
  backend: QuantumBackend,
  shots: number,
  optLevel: 0 | 1 | 2 | 3
): string {
  const sorted = [...gates]
    .filter((g) => g.qubit < numQubits && (g.targetQubit === undefined || g.targetQubit < numQubits))
    .sort((a, b) => a.step - b.step);

  const lines: string[] = [
    'from veritas_quantum import QuantumCloudClient, QuantumCircuit, TranspileOptions',
    '',
    '# Connect to Veritas Quantum Cloud fabric',
    'client = QuantumCloudClient(region="' + backend.region + '")',
    'backend = client.get_backend("' + backend.id + '")',
    '',
    `qc = QuantumCircuit(${numQubits}, ${numQubits})`,
  ];

  for (const g of sorted) {
    const thetaStr = g.angle !== undefined ? g.angle.toFixed(4) : '0.7854';
    switch (g.type) {
      case 'H':
      case 'X':
      case 'Y':
      case 'Z':
      case 'S':
      case 'T':
        lines.push(`qc.${g.type.toLowerCase()}(${g.qubit})`);
        break;
      case 'RX':
      case 'RY':
      case 'RZ':
        lines.push(`qc.${g.type.toLowerCase()}(${thetaStr}, ${g.qubit})`);
        break;
      case 'CNOT':
        lines.push(`qc.cx(${g.qubit}, ${g.targetQubit ?? (g.qubit + 1) % numQubits})`);
        break;
      case 'CZ':
        lines.push(`qc.cz(${g.qubit}, ${g.targetQubit ?? (g.qubit + 1) % numQubits})`);
        break;
      case 'SWAP':
        lines.push(`qc.swap(${g.qubit}, ${g.targetQubit ?? (g.qubit + 1) % numQubits})`);
        break;
    }
  }

  lines.push('qc.measure_all()');
  lines.push('');
  lines.push('# Transpile for hardware coupling map and dynamical decoupling');
  lines.push(
    `compiled = client.transpile(qc, backend=backend, optimization_level=${optLevel}, dd_sequence="XY4")`
  );
  lines.push(
    `job = backend.run(compiled, shots=${shots}, error_mitigation="readout_twirling")`
  );
  lines.push('result = job.result()');
  lines.push('print("Quasi-probabilities:", result.get_quasi_distribution())');
  return lines.join('\n');
}
